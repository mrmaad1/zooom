import type { FastifyInstance } from 'fastify';
import helmet from '@fastify/helmet';

/**
 * Hardened headers. Everything the app needs is same-origin, so CSP can stay
 * tight: no third-party scripts, no framing, no referrer leakage (important
 * because meeting links carry the E2EE key in the fragment).
 */
export async function registerSecurity(app: FastifyInstance, opts: { dev: boolean; allowedOrigins: string[] }) {
  await app.register(helmet, {
    contentSecurityPolicy: opts.dev
      ? false // Vite dev server needs inline/eval for HMR
      : {
          directives: {
            defaultSrc: ["'self'"],
            baseUri: ["'none'"],
            scriptSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            imgSrc: ["'self'", 'data:', 'blob:'],
            mediaSrc: ["'self'", 'blob:'],
            fontSrc: ["'self'"],
            connectSrc: ["'self'", 'ws:', 'wss:'],
            workerSrc: ["'self'", 'blob:'],
            frameAncestors: ["'none'"],
            formAction: ["'none'"],
            objectSrc: ["'none'"],
            upgradeInsecureRequests: [],
          },
        },
    crossOriginEmbedderPolicy: false,
    crossOriginOpenerPolicy: { policy: 'same-origin' },
    referrerPolicy: { policy: 'no-referrer' },
    hsts: { maxAge: 15552000, includeSubDomains: true, preload: false },
    xFrameOptions: { action: 'deny' },
  });

  /**
   * Cross-origin access for split deployments (e.g. static frontend on Vercel,
   * signaling on Render). Only the origins you list get CORS; everything else
   * is rejected, so this cannot be used to embed the app in a random site.
   */
  app.addHook('onRequest', async (request, reply) => {
    const origin = request.headers.origin;
    if (!origin) return;
    const allowed = opts.allowedOrigins.includes(origin);
    if (allowed) {
      reply.header('Access-Control-Allow-Origin', origin);
      reply.header('Vary', 'Origin');
      reply.header('Access-Control-Allow-Methods', 'GET, OPTIONS');
      reply.header('Access-Control-Allow-Headers', 'Content-Type');
      reply.header('Access-Control-Max-Age', '86400');
    } else if (request.method === 'OPTIONS') {
      // preflight from an origin we do not know: no CORS headers = browser blocks it
      reply.code(204).send();
      return;
    }
    if (request.method === 'OPTIONS') {
      reply.code(204).send();
    }
  });

  app.addHook('onSend', async (_req, reply, payload) => {
    reply.header('Permissions-Policy', 'camera=(self), microphone=(self), display-capture=(self), geolocation=(), payment=(), usb=()');
    reply.header('X-Content-Type-Options', 'nosniff');
    // split deploys fetch /api/config from another origin, so allow cross-origin
    // reads of the API while keeping documents same-origin only
    reply.header('Cross-Origin-Resource-Policy', _req.url.startsWith('/api/') ? 'cross-origin' : 'same-origin');
    return payload;
  });
}
