/**
 * Zooom signaling server.
 *
 * Responsibilities (deliberately minimal):
 *   1. serve the built React app
 *   2. relay WebRTC signaling + volatile UI state + already-encrypted chat
 *   3. enforce limits and privacy defaults
 *
 * It never sees media, chat plaintext or the end-to-end encryption key.
 */
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import Fastify from 'fastify';
import websocket from '@fastify/websocket';
import fastifyStatic from '@fastify/static';
import { ClientMessageSchema, ROOM_ID, type ClientConfig } from '../shared/protocol.js';
import { RoomStore, newId, type Participant } from './rooms.js';
import { registerSecurity } from './security.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const DEV = process.argv.includes('--dev');

const PORT = Number(process.env.PORT ?? 3000);
const MAX_PARTICIPANTS = Number(process.env.MAX_PARTICIPANTS ?? 24);
const ALLOW_PUBLIC_STUN = (process.env.ALLOW_PUBLIC_STUN ?? 'true') !== 'false';
const TURN_URLS = (process.env.TURN_URLS ?? '').split(',').map((s) => s.trim()).filter(Boolean);
/** Comma-separated origins allowed to call this API from another domain (split deploys). */
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS ?? '')
  .split(',')
  .map((s) => s.trim().replace(/\/+$/, ''))
  .filter(Boolean);

/** 40 messages / 10s / socket — enough for everything the UI does */
const RATE_WINDOW_MS = 10_000;
const RATE_MAX = 60;

function iceServers(): RTCIceServer[] {
  const servers: RTCIceServer[] = [];
  if (TURN_URLS.length && process.env.TURN_USERNAME) {
    servers.push({
      urls: TURN_URLS,
      username: process.env.TURN_USERNAME,
      credential: process.env.TURN_CREDENTIAL ?? '',
    });
  }
  if (ALLOW_PUBLIC_STUN) {
    servers.push({ urls: ['stun:stun.l.google.com:19302', 'stun:stun.cloudflare.com:3478'] });
  }
  return servers;
}

const config: ClientConfig = {
  maxParticipants: MAX_PARTICIPANTS,
  iceServers: iceServers(),
  privacy: { publicStun: ALLOW_PUBLIC_STUN, turn: TURN_URLS.length > 0, e2eeRequired: false },
  limits: { chatBytes: 8192, nameChars: 42 },
  version: '2.0.0',
};

const app = Fastify({
  logger: false, // no access logs: no IPs, no room ids, no user agents retained
  bodyLimit: 64 * 1024,
  trustProxy: false,
  disableRequestLogging: true,
});

const rooms = new RoomStore();

app.get('/api/health', async () => ({ ok: true, uptime: Math.round(process.uptime()), ...rooms.stats() }));
app.get('/api/config', async (_req, reply) => {
  reply.header('Cache-Control', 'no-store');
  return config;
});

await registerSecurity(app, { dev: DEV, allowedOrigins: ALLOWED_ORIGINS });
await app.register(websocket, { options: { maxPayload: 512 * 1024 } });

/* ------------------------------------------------------------------ */
/* WebSocket: signaling                                                */
/* ------------------------------------------------------------------ */
app.register(async (instance) => {
  instance.get('/ws', { websocket: true }, (socket) => {
    let me: Participant | null = null;
    let roomId: string | null = null;

    const send = (msg: unknown) => {
      if (socket.readyState !== 1) return;
      try {
        socket.send(JSON.stringify(msg));
      } catch {
        /* ignore */
      }
    };
    const close = () => {
      try {
        socket.close();
      } catch {
        /* ignore */
      }
    };

    const budgetOk = (p: Participant) => {
      const now = Date.now();
      if (now - p.msgBudget.windowStart > RATE_WINDOW_MS) {
        p.msgBudget.windowStart = now;
        p.msgBudget.count = 0;
      }
      p.msgBudget.count += 1;
      return p.msgBudget.count <= RATE_MAX;
    };

    socket.on('message', (raw: Buffer) => {
      let parsed: unknown;
      try {
        parsed = JSON.parse(raw.toString());
      } catch {
        return;
      }
      const result = ClientMessageSchema.safeParse(parsed);
      if (!result.success) {
        if (me) send({ type: 'error', reason: 'bad-room' });
        return;
      }
      const msg = result.data;

      /* ---------------- join ---------------- */
      if (msg.type === 'join') {
        if (me) return;
        if (!ROOM_ID.test(msg.room)) return send({ type: 'error', reason: 'bad-room' });

        let room = rooms.get(msg.room);
        if (!room) room = rooms.create(msg.room, msg.e2ee);
        if (room.participants.size >= MAX_PARTICIPANTS) {
          return send({ type: 'error', reason: 'room-full', limit: MAX_PARTICIPANTS });
        }
        room.emptySince = null;

        const participant: Participant = {
          id: newId(),
          name: msg.name,
          muted: msg.muted,
          videoOn: msg.videoOn,
          sharing: false,
          hand: false,
          joinedAt: Date.now(),
          send,
          close,
          msgBudget: { windowStart: Date.now(), count: 0 },
        };
        me = participant;
        roomId = room.id;
        if (!room.hostId) room.hostId = participant.id;
        room.participants.set(participant.id, participant);

        send({
          type: 'joined',
          selfId: participant.id,
          room: room.id,
          hostId: room.hostId,
          encrypted: room.encrypted,
          max: MAX_PARTICIPANTS,
          participants: rooms.roster(room),
          chat: room.chat.slice(-MAX_PARTICIPANTS * 5),
        });
        rooms.broadcast(
          room,
          {
            type: 'peer-joined',
            participant: {
              id: participant.id,
              name: participant.name,
              muted: participant.muted,
              videoOn: participant.videoOn,
              sharing: false,
              hand: false,
              isHost: room.hostId === participant.id,
            },
          },
          participant.id
        );
        rooms.system(room, `${participant.name} joined the meeting`);
        return;
      }

      if (!me || !roomId) return;
      const room = rooms.get(roomId);
      if (!room) return;
      if (!budgetOk(me)) {
        send({ type: 'error', reason: 'rate-limited' });
        return;
      }

      switch (msg.type) {
        case 'signal': {
          const target = room.participants.get(msg.to);
          if (target) target.send({ type: 'signal', from: me.id, data: msg.data });
          break;
        }
        case 'state': {
          if (typeof msg.muted === 'boolean') me.muted = msg.muted;
          if (typeof msg.videoOn === 'boolean') me.videoOn = msg.videoOn;
          if (typeof msg.sharing === 'boolean') me.sharing = msg.sharing;
          rooms.broadcast(room, {
            type: 'peer-state',
            id: me.id,
            muted: me.muted,
            videoOn: me.videoOn,
            sharing: me.sharing,
          });
          break;
        }
        case 'hand': {
          me.hand = msg.hand;
          rooms.broadcast(room, { type: 'peer-hand', id: me.id, hand: me.hand });
          break;
        }
        case 'rename': {
          if (msg.name === me.name) break;
          me.name = msg.name;
          rooms.broadcast(room, { type: 'peer-renamed', id: me.id, name: me.name });
          break;
        }
        case 'chat': {
          const message = {
            id: newId(),
            from: me.id,
            name: me.name,
            ct: msg.ct, // ciphertext only — the server cannot read it
            iv: msg.iv,
            to: msg.to,
            ts: Date.now(),
          };
          if (msg.to !== 'everyone') {
            const target = room.participants.get(msg.to);
            if (!target) break;
            me.send({ type: 'chat', message });
            target.send({ type: 'chat', message });
          } else {
            rooms.pushChat(room, message);
            rooms.broadcast(room, { type: 'chat', message });
          }
          break;
        }
        case 'reaction': {
          rooms.broadcast(room, { type: 'reaction', id: me.id, name: me.name, emoji: msg.emoji });
          break;
        }
        case 'mute-all': {
          if (room.hostId !== me.id) break;
          for (const p of room.participants.values()) {
            if (p.id === me.id) continue;
            p.muted = true;
            p.send({ type: 'mute-request' });
            rooms.broadcast(room, { type: 'peer-state', id: p.id, muted: true, videoOn: p.videoOn, sharing: p.sharing });
          }
          rooms.system(room, 'The host muted all participants');
          break;
        }
        case 'ask-mute': {
          if (room.hostId !== me.id) break;
          room.participants.get(msg.id)?.send({ type: 'mute-request' });
          break;
        }
        case 'remove': {
          if (room.hostId !== me.id || msg.id === me.id) break;
          rooms.remove(room, msg.id, { removed: true });
          break;
        }
        case 'leave': {
          rooms.remove(room, me.id);
          me = null;
          roomId = null;
          break;
        }
      }
    });

    socket.on('close', () => {
      if (me && roomId) {
        const room = rooms.get(roomId);
        if (room) rooms.remove(room, me.id);
      }
      me = null;
      roomId = null;
    });
    socket.on('error', () => {
      /* ignore */
    });
  });
});

/* keep-alive + reaping */
setInterval(() => {
  rooms.reap(5000);
}, 5000).unref();

/* ------------------------------------------------------------------ */
/* Static app                                                          */
/* ------------------------------------------------------------------ */
if (DEV) {
  const { createServer } = await import('vite');
  const vite = await createServer({
    root: ROOT,
    appType: 'spa',
    server: { middlewareMode: true },
  });
  app.addHook('onRequest', (req, reply, done) => {
    // let vite handle everything that is not an API/WS route
    if (req.raw.url && /^\/(api|ws)/.test(req.raw.url)) return done();
    reply.hijack();
    vite.middlewares(req.raw, reply.raw, () => done());
  });
} else {
  await app.register(fastifyStatic, {
    root: path.join(ROOT, 'dist'),
    prefix: '/',
    wildcard: true,
    index: 'index.html',
    setHeaders(res, filePath) {
      if (/\.(js|css|woff2?|svg)$/.test(filePath)) {
        res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      } else {
        res.setHeader('Cache-Control', 'no-cache');
      }
    },
  });
  app.setNotFoundHandler((req, reply) => {
    if (/^\/(api|ws)/.test(req.raw.url ?? '')) return reply.code(404).send({ error: 'not found' });
    return reply.sendFile('index.html');
  });
}

app.listen({ port: PORT, host: '0.0.0.0' }).then(() => {
  // eslint-disable-next-line no-console
  console.log(`Zooom ${DEV ? '(dev)' : ''} listening on :${PORT} · publicSTUN=${ALLOW_PUBLIC_STUN} · turn=${TURN_URLS.length > 0}`);
});
