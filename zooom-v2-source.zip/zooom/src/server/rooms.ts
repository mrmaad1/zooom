/**
 * In-memory, ephemeral room registry.
 * Nothing is written to disk, nothing is logged, and rooms are dropped as soon
 * as they are empty (plus a short grace period for reconnects).
 */
import { randomBytes } from 'node:crypto';
import type { ChatEnvelope, PeerInfo } from '../shared/protocol.js';

export interface Participant {
  id: string;
  name: string;
  muted: boolean;
  videoOn: boolean;
  sharing: boolean;
  hand: boolean;
  joinedAt: number;
  send: (msg: unknown) => void;
  close: () => void;
  msgBudget: { windowStart: number; count: number };
}

export interface Room {
  id: string;
  createdAt: number;
  hostId: string;
  encrypted: boolean;
  participants: Map<string, Participant>;
  chat: ChatEnvelope[];
  emptySince: number | null;
}

const MAX_CHAT_HISTORY = 120;
export const newId = () => randomBytes(9).toString('base64url').slice(0, 10);

export class RoomStore {
  private rooms = new Map<string, Room>();

  get(id: string): Room | undefined {
    return this.rooms.get(id);
  }

  create(id: string, encrypted: boolean): Room {
    const room: Room = {
      id,
      createdAt: Date.now(),
      hostId: '',
      encrypted,
      participants: new Map(),
      chat: [],
      emptySince: null,
    };
    this.rooms.set(id, room);
    return room;
  }

  roster(room: Room): PeerInfo[] {
    return [...room.participants.values()].map((p) => ({
      id: p.id,
      name: p.name,
      muted: p.muted,
      videoOn: p.videoOn,
      sharing: p.sharing,
      hand: p.hand,
      isHost: p.id === room.hostId,
    }));
  }

  broadcast(room: Room, msg: unknown, exceptId?: string) {
    for (const p of room.participants.values()) {
      if (p.id === exceptId) continue;
      p.send(msg);
    }
  }

  pushChat(room: Room, message: ChatEnvelope) {
    room.chat.push(message);
    if (room.chat.length > MAX_CHAT_HISTORY) room.chat.shift();
  }

  system(room: Room, text: string) {
    const message: ChatEnvelope = { id: newId(), system: true, text, ts: Date.now() };
    this.pushChat(room, message);
    this.broadcast(room, { type: 'chat', message });
  }

  remove(room: Room, participantId: string, opts: { removed?: boolean } = {}) {
    const p = room.participants.get(participantId);
    if (!p) return;
    room.participants.delete(participantId);

    if (opts.removed) {
      p.send({ type: 'removed' });
      p.close();
    }
    this.broadcast(room, { type: 'peer-left', id: p.id, name: p.name });
    this.system(room, `${p.name} ${opts.removed ? 'was removed from the meeting' : 'left the meeting'}`);

    if (room.hostId === p.id && room.participants.size > 0) {
      const next = [...room.participants.values()].sort((a, b) => a.joinedAt - b.joinedAt)[0]!;
      room.hostId = next.id;
      this.broadcast(room, { type: 'host-changed', hostId: next.id });
      this.system(room, `${next.name} is now the host`);
    }
    if (room.participants.size === 0) room.emptySince = Date.now();
  }

  /** drop rooms that stayed empty for more than `graceMs` */
  reap(graceMs = 5000) {
    const now = Date.now();
    for (const [id, room] of this.rooms) {
      if (room.participants.size === 0 && room.emptySince && now - room.emptySince > graceMs) {
        this.rooms.delete(id);
      }
    }
  }

  stats() {
    let people = 0;
    for (const room of this.rooms.values()) people += room.participants.size;
    return { rooms: this.rooms.size, people };
  }
}
