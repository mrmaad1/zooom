/**
 * Wire protocol shared by client and server.
 *
 * Privacy notes
 * -------------
 * - SDP / ICE and UI state are relayed; media is strictly peer-to-peer.
 * - Chat payloads are ALREADY encrypted by the client (`ct` + `iv`). The server
 *   never sees message plaintext.
 * - The end-to-end media key lives only in the URL fragment (`#k=…`) on the
 *   client. It is never sent to the server.
 * - System chat lines (join/leave) are plaintext by design and contain only the
 *   display name the participant typed.
 */
import { z } from 'zod';

export const ROOM_ID = /^\d{9,12}$/;
export const MAX_NAME = 42;
export const MAX_CHAT_CIPHERTEXT = 8192;

const roomId = z.string().regex(ROOM_ID, 'invalid room id');
const name = z.string().trim().min(1).max(MAX_NAME);
const peerId = z.string().regex(/^[A-Za-z0-9_-]{6,32}$/, 'invalid peer id');

const sdp = z.object({
  type: z.enum(['offer', 'answer', 'pranswer', 'rollback']),
  sdp: z.string().max(300_000),
});
const candidate = z.object({
  candidate: z.string().max(4096),
  sdpMid: z.string().max(64).nullable().optional(),
  sdpMLineIndex: z.number().int().min(0).max(64).nullable().optional(),
  usernameFragment: z.string().max(256).nullable().optional(),
});
const signalData = z.union([z.object({ sdp }), z.object({ candidate })]);
export type SignalPayload = { sdp: { type: 'offer' | 'answer' | 'pranswer' | 'rollback'; sdp: string } } | { candidate: { candidate: string; sdpMid?: string | null; sdpMLineIndex?: number | null; usernameFragment?: string | null } };

/** client -> server */
export const ClientMessageSchema = z.discriminatedUnion('type', [
  z.object({ type: z.literal('join'), room: roomId, name, muted: z.boolean(), videoOn: z.boolean(), e2ee: z.boolean() }),
  z.object({ type: z.literal('signal'), to: peerId, data: signalData }),
  z.object({
    type: z.literal('state'),
    muted: z.boolean().optional(),
    videoOn: z.boolean().optional(),
    sharing: z.boolean().optional(),
  }),
  z.object({ type: z.literal('hand'), hand: z.boolean() }),
  z.object({ type: z.literal('rename'), name }),
  z.object({
    type: z.literal('chat'),
    ct: z.string().min(1).max(MAX_CHAT_CIPHERTEXT),
    iv: z.string().min(8).max(64),
    to: z.union([z.literal('everyone'), peerId]),
  }),
  z.object({ type: z.literal('reaction'), emoji: z.string().min(1).max(8) }),
  z.object({ type: z.literal('mute-all') }),
  z.object({ type: z.literal('ask-mute'), id: peerId }),
  z.object({ type: z.literal('remove'), id: peerId }),
  z.object({ type: z.literal('leave') }),
]);
export type ClientMessage = z.infer<typeof ClientMessageSchema>;

/** server -> client */
export interface PeerInfo {
  id: string;
  name: string;
  muted: boolean;
  videoOn: boolean;
  sharing: boolean;
  hand: boolean;
  isHost: boolean;
}
export interface ChatEnvelope {
  id: string;
  ts: number;
  from?: string;
  name?: string;
  ct?: string;
  iv?: string;
  to?: 'everyone' | string;
  system?: boolean;
  text?: string;
}
export type ServerMessage =
  | {
      type: 'joined';
      selfId: string;
      room: string;
      hostId: string;
      encrypted: boolean;
      max: number;
      participants: PeerInfo[];
      chat: ChatEnvelope[];
    }
  | { type: 'peer-joined'; participant: PeerInfo }
  | { type: 'peer-left'; id: string; name: string }
  | { type: 'signal'; from: string; data: unknown }
  | { type: 'peer-state'; id: string; muted: boolean; videoOn: boolean; sharing: boolean }
  | { type: 'peer-hand'; id: string; hand: boolean }
  | { type: 'peer-renamed'; id: string; name: string }
  | { type: 'host-changed'; hostId: string }
  | { type: 'chat'; message: ChatEnvelope }
  | { type: 'reaction'; id: string; name: string; emoji: string }
  | { type: 'mute-request' }
  | { type: 'removed' }
  | { type: 'error'; reason: 'room-full' | 'bad-room' | 'rate-limited' | 'server-error'; limit?: number };

export interface ClientConfig {
  maxParticipants: number;
  iceServers: RTCIceServer[];
  privacy: { publicStun: boolean; turn: boolean; e2eeRequired: boolean };
  limits: { chatBytes: number; nameChars: number };
  version: string;
}
