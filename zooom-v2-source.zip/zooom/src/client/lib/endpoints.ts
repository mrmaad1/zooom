/**
 * Where the API + signaling server lives.
 *
 * Three deployment shapes are supported:
 *
 *   1. All-in-one (Docker / Render / Fly / a VPS)  → nothing to configure.
 *      The client talks to the same origin it was served from.
 *
 *   2. Static frontend on Vercel + signaling elsewhere
 *      → set VITE_API_BASE=https://zooom-signal.onrender.com at build time.
 *        Vercel is serverless and cannot hold a WebSocket open, so the WS
 *        server has to live on a platform with long-lived connections.
 *
 *   3. Custom WS URL (a proxy, Cloudflare Worker, …)
 *      → set VITE_WS_URL=wss://example.com/ws (overrides everything else).
 */
const apiBase = (import.meta.env.VITE_API_BASE ?? '').trim().replace(/\/+$/, '');
const wsOverride = (import.meta.env.VITE_WS_URL ?? '').trim();

/** Base URL for REST calls (`''` = same origin). */
export const API_BASE = apiBase;

export function apiUrl(path: string): string {
  return `${API_BASE}${path.startsWith('/') ? path : `/${path}`}`;
}

/** Full WebSocket URL for the signaling endpoint. */
export function signalingUrl(): string {
  if (wsOverride) return wsOverride;
  if (apiBase) return `${apiBase.replace(/^http/, 'ws')}/ws`;
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${proto}//${location.host}/ws`;
}

/** True when the frontend and the signaling server are on different origins. */
export const IS_SPLIT_DEPLOY = API_BASE !== '' && !API_BASE.startsWith(location.origin);
