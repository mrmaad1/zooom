/**
 * Local-only recorder. Composites every video element on screen into a canvas and
 * mixes all participant audio, then writes a WebM straight to the user's disk.
 * Nothing is uploaded and no server endpoint is involved.
 */
export class LocalRecorder {
  private recorder: MediaRecorder | null = null;
  private chunks: BlobPart[] = [];
  private ctx: AudioContext | null = null;
  private raf = 0;
  startedAt = 0;
  onTick: (elapsedMs: number) => void = () => {};
  private timer = 0;

  get recording() {
    return this.recorder?.state === 'recording';
  }

  async start(videos: () => HTMLVideoElement[], audioStreams: () => MediaStream[]): Promise<boolean> {
    if (!window.MediaRecorder || this.recording) return false;
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 1280;
      canvas.height = 720;
      const ctx2d = canvas.getContext('2d');
      if (!ctx2d) return false;
      const out = canvas.captureStream(24);

      const audioCtx = new AudioContext();
      const dest = audioCtx.createMediaStreamDestination();
      for (const stream of audioStreams()) {
        if (stream.getAudioTracks().length === 0) continue;
        try {
          audioCtx.createMediaStreamSource(stream).connect(dest);
        } catch {
          /* ignore */
        }
      }
      dest.stream.getAudioTracks().forEach((track) => out.addTrack(track));
      this.ctx = audioCtx;

      const mimeType = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'].find((m) =>
        MediaRecorder.isTypeSupported(m)
      );

      this.chunks = [];
      const recorder = new MediaRecorder(out, mimeType ? { mimeType, videoBitsPerSecond: 2_500_000 } : undefined);
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) this.chunks.push(event.data);
      };
      recorder.start(1000);
      this.recorder = recorder;
      this.startedAt = Date.now();

      const draw = () => {
        if (this.recorder?.state !== 'recording') return;
        ctx2d.fillStyle = '#0c0c0c';
        ctx2d.fillRect(0, 0, canvas.width, canvas.height);
        const live = videos().filter((v) => v.videoWidth > 0);
        if (live.length === 0) {
          ctx2d.fillStyle = '#5a5a5a';
          ctx2d.font = '600 22px system-ui, sans-serif';
          ctx2d.textAlign = 'center';
          ctx2d.fillText('Zooom meeting', canvas.width / 2, canvas.height / 2);
        } else {
          const cols = live.length === 1 ? 1 : live.length <= 4 ? 2 : 3;
          const rows = Math.ceil(live.length / cols);
          const pad = 8;
          const cellW = (canvas.width - pad * (cols + 1)) / cols;
          const cellH = (canvas.height - pad * (rows + 1)) / rows;
          live.forEach((video, index) => {
            const x = pad + (index % cols) * (cellW + pad);
            const y = pad + Math.floor(index / cols) * (cellH + pad);
            const scale = Math.min(cellW / video.videoWidth, cellH / video.videoHeight);
            const w = video.videoWidth * scale;
            const h = video.videoHeight * scale;
            ctx2d.drawImage(video, x + (cellW - w) / 2, y + (cellH - h) / 2, w, h);
          });
        }
        this.raf = requestAnimationFrame(draw);
      };
      draw();
      this.timer = window.setInterval(() => this.onTick(Date.now() - this.startedAt), 500);
      return true;
    } catch {
      return false;
    }
  }

  stop(): Promise<{ blob: Blob; mimeType: string } | null> {
    return new Promise((resolve) => {
      const recorder = this.recorder;
      if (!recorder) return resolve(null);
      const mimeType = recorder.mimeType || 'video/webm';
      recorder.onstop = () => {
        const blob = new Blob(this.chunks, { type: mimeType });
        this.chunks = [];
        resolve({ blob, mimeType });
      };
      try {
        recorder.stop();
      } catch {
        resolve(null);
      }
      this.recorder = null;
      cancelAnimationFrame(this.raf);
      window.clearInterval(this.timer);
      if (this.ctx) {
        void this.ctx.close();
        this.ctx = null;
      }
    });
  }
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}
