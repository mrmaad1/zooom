/**
 * All persistence is local (localStorage). The server stores nothing.
 */
export interface ScheduledMeeting {
  id: string;
  room: string;
  title: string;
  when: string;
  dur: number;
}

export interface RecentMeeting {
  room: string;
  title: string;
  ts: number;
}

export interface RecordingEntry {
  name: string;
  ts: number;
  size: string;
}

const ns = 'zooom.v2.';

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(ns + key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  try {
    localStorage.setItem(ns + key, JSON.stringify(value));
  } catch {
    /* storage full / disabled */
  }
}

export const storage = {
  profileName: () => read<string>('name', ''),
  setProfileName: (name: string) => write('name', name),
  pmi: () => {
    const existing = read<string>('pmi', '');
    return existing;
  },
  setPmi: (pmi: string) => write('pmi', pmi),
  meetings: () => read<ScheduledMeeting[]>('meetings', []),
  setMeetings: (list: ScheduledMeeting[]) => write('meetings', list),
  recents: () => read<RecentMeeting[]>('recents', []),
  setRecents: (list: RecentMeeting[]) => write('recents', list),
  recordings: () => read<RecordingEntry[]>('recordings', []),
  setRecordings: (list: RecordingEntry[]) => write('recordings', list),
  privacyPrefs: () => read<{ hidePreview?: boolean }>('privacy', {}),
  setPrivacyPrefs: (prefs: { hidePreview?: boolean }) => write('privacy', prefs),
};
