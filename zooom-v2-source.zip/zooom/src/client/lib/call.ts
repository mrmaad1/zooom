/**
 * CallSession — the WebRTC mesh engine.
 *
 * Deliberately framework-free: React only subscribes to snapshots and calls
 * intent methods. Keeps the media/signaling logic testable and out of render.
 *
 * Privacy properties
 * ------------------
 * • media is peer-to-peer; the server only relays SDP/ICE
 * • outgoing media is encrypted with the meeting key (insertable streams)
 * • chat text is AES-GCM sealed in the browser before it is sent
 * • the key never leaves the browser; it is not part of any signaling message
 */
import type { ChatEnvelope, ClientConfig, ClientMessage, PeerInfo, ServerMessage, SignalPayload } from '../../shared/protocol.js';
import { decryptReceiver, encryptSender, keyFromFragment, openText, sealText, type Sealed } from './e2ee.js';
import type { LocalMedia } from './media.js';

export interface CallParticipant extends PeerInfo {
  self: boolean;
}

export interface ChatItem {
  id: string;
  ts: number;
  from?: string;
  name?: string;
  text?: string;
  system?: boolean;
  mine?: boolean;
  privateTo?: string;
  locked?: boolean;
}

export interface CallSnapshot {
  status: 'idle' | 'connecting' | 'joined' | 'error';
  room: string | null;
  selfId: string | null;
  hostId: string | null;
  participants: CallParticipant[];
  streams: Record<string, MediaStream>;
  e2eeActive: boolean;
  e2eeSupported: boolean;
  encryptedRoom: boolean;
  hasKey: boolean;
  startedAt: number | null;
  error: 'room-full' | 'bad-room' | 'rate-limited' | 'offline' | null;
  maxParticipants: number;
}

interface Peer {
  id: string;
  info: PeerInfo;
  pc: RTCPeerConnection | null;
  stream: MediaStream;
  pending: RTCIceCandidateInit[];
  audioSender: RTCRtpSender | null;
  videoSender: RTCRtpSender | null;
  polite: boolean;
}

const emptySnapshot: CallSnapshot = {
  status: 'idle',
  room: null,
  selfId: null,
  hostId: null,
  participants: [],
  streams: {},
  e2eeActive: false,
  e2eeSupported: false,
  encryptedRoom: false,
  hasKey: false,
  startedAt: null,
  error: null,
  maxParticipants: 24,
};

export class CallSession {
  private ws: WebSocket | null = null;
  private peers = new Map<string, Peer>();
  private media: LocalMedia | null = null;
  private config: ClientConfig | null = null;
  private key: Uint8Array | null = null;
  private selfName = 'Guest';
  private snapshot: CallSnapshot = { ...emptySnapshot };
  private chat: ChatItem[] = [];
  private chatKeys = new Set<string>();

  onSnapshot: (snapshot: CallSnapshot) => void = () => {};
  onChat: (items: ChatItem[]) => void = () => {};
  onEvent: (event: { type: 'reaction'; emoji: string } | { type: 'mute-request' } | { type: 'removed' } | { type: 'error'; message: string }) => void =
    () => {};

  /* ------------------------------------------------------------------ */
  /* lifecycle                                                           */
  /* ------------------------------------------------------------------ */
  async join(options: {
    room: string;
    name: string;
    key: Uint8Array | null;
    media: LocalMedia;
    config: ClientConfig;
    muted: boolean;
    videoOn: boolean;
  }) {
    this.leave({ silent: true });
    this.config = options.config;
    this.media = options.media;
    this.key = options.key;
    this.selfName = options.name;
    this.chat = [];
    this.chatKeys.clear();
    this.onChat([]);

    const e2eeSupported = typeof window !== 'undefined' && 'RTCRtpScriptTransform' in window;
    this.snapshot = {
      ...emptySnapshot,
      status: 'connecting',
      room: options.room,
      maxParticipants: options.config.maxParticipants,
      e2eeSupported,
      e2eeActive: !!options.key && e2eeSupported,
      hasKey: !!options.key,
      startedAt: null,
      participants: [
        {
          id: 'self',
          name: options.name,
          muted: options.muted,
          videoOn: options.videoOn,
          sharing: false,
          hand: false,
          isHost: false,
          self: true,
        },
      ],
    };
    this.publish();

    await this.connect({ muted: this.snapshot.participants[0]!.muted, videoOn: this.snapshot.participants[0]!.videoOn });
  }

  private connect(opts: { muted: boolean; videoOn: boolean }) {
    return new Promise<void>((resolve) => {
      
      const ws = new WebSocket(signalingUrl());
      this.ws = ws;

      const timeout = window.setTimeout(() => {
        if (this.snapshot.status === 'connecting') {
          this.patch({ status: 'error', error: 'offline' });
          ws.close();
          resolve();
        }
      }, 12000);

      ws.addEventListener('open', () => {
        this.send({
          type: 'join',
          room: this.snapshot.room!,
          name: this.selfName,
          muted: opts.muted,
          videoOn: opts.videoOn,
          e2ee: !!this.key,
        });
        resolve();
      });

      ws.addEventListener('message', (event) => {
        let msg: ServerMessage;
        try {
          msg = JSON.parse(String(event.data)) as ServerMessage;
        } catch {
          return;
        }
        void this.handle(msg);
      });

      ws.addEventListener('close', () => {
        window.clearTimeout(timeout);
        if (this.snapshot.status === 'joined') {
          this.patch({ status: 'error', error: 'offline' });
        }
        resolve();
      });

      ws.addEventListener('error', () => {
        window.clearTimeout(timeout);
        if (this.snapshot.status === 'connecting') {
          this.patch({ status: 'error', error: 'offline' });
        }
        resolve();
      });
    });
  }

  leave(options: { silent?: boolean } = {}) {
    this.send({ type: 'leave' });
    this.peers.forEach((peer) => {
      try {
        peer.pc?.close();
      } catch {
        /* ignore */
      }
    });
    this.peers.clear();
    try {
      this.ws?.close();
    } catch {
      /* ignore */
    }
    this.ws = null;
    this.snapshot = { ...emptySnapshot, e2eeSupported: this.snapshot.e2eeSupported };
    this.chat = [];
    if (!options.silent) this.onChat([]);
    this.publish();
  }

  /* ------------------------------------------------------------------ */
  /* signaling                                                           */
  /* ------------------------------------------------------------------ */
  private send(msg: ClientMessage) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify(msg));
      } catch {
        /* ignore */
      }
    }
  }

  private async handle(msg: ServerMessage) {
    switch (msg.type) {
      case 'joined': {
        this.patch({
          status: 'joined',
          selfId: msg.selfId,
          hostId: msg.hostId,
          encryptedRoom: msg.encrypted,
          startedAt: Date.now(),
          maxParticipants: msg.max,
          error: null,
        });
        for (const p of msg.participants) {
          if (p.id === msg.selfId) continue;
          this.peers.set(p.id, {
            id: p.id,
            info: p,
            pc: null,
            stream: new MediaStream(),
            pending: [],
            audioSender: null,
            videoSender: null,
            polite: false,
          });
        }
        this.syncParticipants();
        void this.hydrateChat(msg.chat);
        // the new joiner starts negotiation with everyone already in the room
        for (const peer of this.peers.values()) void this.makeOffer(peer.id);
        break;
      }
      case 'peer-joined': {
        if (!this.peers.has(msg.participant.id)) {
          this.peers.set(msg.participant.id, {
            id: msg.participant.id,
            info: msg.participant,
            pc: null,
            stream: new MediaStream(),
            pending: [],
            audioSender: null,
            videoSender: null,
            polite: false,
          });
        }
        this.syncParticipants();
        break;
      }
      case 'peer-left': {
        const peer = this.peers.get(msg.id);
        if (peer) {
          try {
            peer.pc?.close();
          } catch {
            /* ignore */
          }
          this.peers.delete(msg.id);
        }
        this.syncParticipants();
        break;
      }
      case 'signal': {
        await this.onSignal(msg.from, msg.data);
        break;
      }
      case 'peer-state': {
        const peer = this.peers.get(msg.id);
        if (peer) {
          peer.info = { ...peer.info, muted: msg.muted, videoOn: msg.videoOn, sharing: msg.sharing };
          this.syncParticipants();
        }
        break;
      }
      case 'peer-hand': {
        const peer = this.peers.get(msg.id);
        if (peer) {
          peer.info = { ...peer.info, hand: msg.hand };
          this.syncParticipants();
        }
        break;
      }
      case 'peer-renamed': {
        const peer = this.peers.get(msg.id);
        if (peer) {
          peer.info = { ...peer.info, name: msg.name };
          this.syncParticipants();
        }
        break;
      }
      case 'host-changed': {
        this.patch({ hostId: msg.hostId });
        this.syncParticipants();
        break;
      }
      case 'chat': {
        await this.ingestChat(msg.message);
        break;
      }
      case 'reaction': {
        this.onEvent({ type: 'reaction', emoji: msg.emoji });
        break;
      }
      case 'mute-request': {
        this.onEvent({ type: 'mute-request' });
        break;
      }
      case 'removed': {
        this.onEvent({ type: 'removed' });
        this.leave();
        break;
      }
      case 'error': {
        this.patch({ status: 'error', error: msg.reason === 'room-full' ? 'room-full' : msg.reason === 'rate-limited' ? 'rate-limited' : 'bad-room' });
        break;
      }
    }
  }

  /* ------------------------------------------------------------------ */
  /* peers                                                               */
  /* ------------------------------------------------------------------ */
  private ensurePeer(id: string): Peer | null {
    let peer = this.peers.get(id);
    if (!peer) {
      peer = {
        id,
        info: { id, name: 'Guest', muted: false, videoOn: false, sharing: false, hand: false, isHost: false },
        pc: null,
        stream: new MediaStream(),
        pending: [],
        audioSender: null,
        videoSender: null,
        polite: false,
      };
      this.peers.set(id, peer);
    }
    if (peer.pc || !this.media) return peer;

    const pc = new RTCPeerConnection({
      iceServers: this.config?.iceServers ?? [],
      bundlePolicy: 'max-bundle',
      rtcpMuxPolicy: 'require',
    });
    peer.pc = pc;

    const audio = this.media.outgoingAudio();
    const video = this.media.outgoingVideo();
    if (audio) peer.audioSender = pc.addTrack(audio, this.media.stream);
    if (video) peer.videoSender = pc.addTrack(video, this.media.stream);

    pc.onicecandidate = (event) => {
      if (event.candidate) this.send({ type: 'signal', to: id, data: { candidate: event.candidate.toJSON() } as SignalPayload });
    };
    pc.ontrack = (event) => {
      if (this.key) decryptReceiver(event.receiver, this.key);
      if (!peer!.stream.getTracks().includes(event.track)) peer!.stream.addTrack(event.track);
      this.publishStreams();
    };
    pc.onsignalingstatechange = () => {
      if (pc.signalingState === 'stable') this.syncTransforms(peer!);
    };
    pc.onnegotiationneeded = () => this.syncTransforms(peer!);
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'failed') {
        try {
          pc.restartIce();
        } catch {
          /* ignore */
        }
      }
    };
    this.syncTransforms(peer);
    return peer;
  }

  /**
   * Attach encrypt/decrypt transforms to every sender/receiver of a connection.
   * Callers can spam this: e2ee.ts remembers which objects are already handled,
   * and renegotiation-created receivers are picked up on the next call.
   */
  private syncTransforms(peer: Peer) {
    if (!this.key || !peer.pc) return;
    const key = this.key;
    try {
      for (const sender of peer.pc.getSenders()) encryptSender(sender, key);
      for (const receiver of peer.pc.getReceivers()) decryptReceiver(receiver, key);
    } catch {
      /* ignore */
    }
  }

  private async makeOffer(id: string) {
    const peer = this.ensurePeer(id);
    if (!peer?.pc || peer.pc.signalingState !== 'stable') return;
    try {
      const offer = await peer.pc.createOffer();
      await peer.pc.setLocalDescription(offer);
      this.syncTransforms(peer);
      this.send({ type: 'signal', to: id, data: { sdp: peer.pc.localDescription?.toJSON() } as unknown as SignalPayload });
    } catch {
      /* ignore */
    }
  }

  private async onSignal(from: string, data: unknown) {
    const payload = data as { sdp?: RTCSessionDescriptionInit; candidate?: RTCIceCandidateInit };
    const peer = this.ensurePeer(from);
    if (!peer?.pc) return;
    const pc = peer.pc;
    try {
      if (payload.sdp) {
        await pc.setRemoteDescription(payload.sdp);
        for (const candidate of peer.pending) {
          try {
            await pc.addIceCandidate(candidate);
          } catch {
            /* ignore */
          }
        }
        peer.pending = [];
        this.syncTransforms(peer);
        if (payload.sdp.type === 'offer') {
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          this.syncTransforms(peer);
          this.send({ type: 'signal', to: from, data: { sdp: pc.localDescription?.toJSON() } as unknown as SignalPayload });
        }
      } else if (payload.candidate) {
        if (pc.remoteDescription) {
          try {
            await pc.addIceCandidate(payload.candidate);
          } catch {
            /* ignore */
          }
        } else {
          peer.pending.push(payload.candidate);
        }
      }
    } catch {
      /* ignore */
    }
  }

  /** re-attach outgoing tracks after a device switch / screen share start-stop */
  rewireTracks() {
    if (!this.media) return;
    const audio = this.media.outgoingAudio();
    const video = this.media.outgoingVideo();
    for (const peer of this.peers.values()) {
      if (!peer.pc) continue;
      let needsOffer = false;
      if (audio && !peer.audioSender) {
        peer.audioSender = peer.pc.addTrack(audio, this.media.stream);
        needsOffer = true;
      } else if (audio && peer.audioSender) {
        void peer.audioSender.replaceTrack(audio);
      }
      if (video && !peer.videoSender) {
        peer.videoSender = peer.pc.addTrack(video, this.media.stream);
        needsOffer = true;
      } else if (video && peer.videoSender) {
        void peer.videoSender.replaceTrack(video);
      }
      this.syncTransforms(peer);
      if (needsOffer) window.setTimeout(() => void this.makeOffer(peer.id), 50);
    }
  }

  /* ------------------------------------------------------------------ */
  /* intents                                                             */
  /* ------------------------------------------------------------------ */
  publishState(state: { muted: boolean; videoOn: boolean; sharing: boolean }) {
    this.send({ type: 'state', ...state });
    const self = this.snapshot.participants.find((p) => p.self);
    if (self) {
      self.muted = state.muted;
      self.videoOn = state.videoOn;
      self.sharing = state.sharing;
      this.syncParticipants();
    }
  }

  async sendChat(text: string, to: string = 'everyone') {
    const trimmed = text.trim();
    if (!trimmed) return;
    if (!this.key) {
      this.onEvent({ type: 'error', message: 'No meeting key — chat is unavailable' });
      return;
    }
    const sealed = await sealText(trimmed, this.key);
    this.send({ type: 'chat', ct: sealed.ct, iv: sealed.iv, to: to === 'everyone' ? 'everyone' : to });
  }

  reaction(emoji: string) {
    this.send({ type: 'reaction', emoji });
  }

  raiseHand(hand: boolean) {
    this.send({ type: 'hand', hand });
    const self = this.snapshot.participants.find((p) => p.self);
    if (self) {
      self.hand = hand;
      this.syncParticipants();
    }
  }

  rename(name: string) {
    this.selfName = name;
    this.send({ type: 'rename', name });
    const self = this.snapshot.participants.find((p) => p.self);
    if (self) {
      self.name = name;
      this.syncParticipants();
    }
  }

  muteAll() {
    this.send({ type: 'mute-all' });
  }

  askMute(id: string) {
    this.send({ type: 'ask-mute', id });
  }

  remove(id: string) {
    this.send({ type: 'remove', id });
  }

  /* ------------------------------------------------------------------ */
  /* chat hydration / decryption                                         */
  /* ------------------------------------------------------------------ */
  private async hydrateChat(history: ChatEnvelope[]) {
    for (const envelope of history) await this.ingestChat(envelope);
  }

  private async ingestChat(envelope: ChatEnvelope) {
    if (this.chatKeys.has(envelope.id)) return;
    this.chatKeys.add(envelope.id);

    if (envelope.system) {
      this.pushChat({ id: envelope.id, ts: envelope.ts, text: envelope.text, system: true });
      return;
    }
    const sealed: Sealed = { ct: envelope.ct ?? '', iv: envelope.iv ?? '' };
    const text = await openText(sealed, this.key);
    this.pushChat({
      id: envelope.id,
      ts: envelope.ts,
      from: envelope.from,
      name: envelope.name,
      text: text ?? undefined,
      locked: text === null,
      mine: envelope.from === this.snapshot.selfId,
      privateTo: envelope.to !== 'everyone' ? envelope.to : undefined,
    });
  }

  private pushChat(item: ChatItem) {
    this.chat = [...this.chat, item];
    this.onChat(this.chat);
  }

  /* ------------------------------------------------------------------ */
  /* snapshot plumbing                                                   */
  /* ------------------------------------------------------------------ */
  private syncParticipants() {
    const self = this.snapshot.participants.find((p) => p.self);
    const others = [...this.peers.values()].map((peer) => ({
      ...peer.info,
      isHost: peer.id === this.snapshot.hostId,
      self: false,
    }));
    const participants = self
      ? [{ ...self, isHost: self.id === this.snapshot.hostId, self: true }, ...others]
      : others;
    this.patch({ participants });
  }

  private publishStreams() {
    const streams: Record<string, MediaStream> = {};
    for (const peer of this.peers.values()) streams[peer.id] = peer.stream;
    this.patch({ streams });
  }

  private patch(partial: Partial<CallSnapshot>) {
    this.snapshot = { ...this.snapshot, ...partial };
    this.publish();
  }

  private publish() {
    this.snapshot.e2eeActive = !!this.key && this.snapshot.e2eeSupported;
    this.onSnapshot(this.snapshot);
  }

  getSnapshot(): CallSnapshot {
    return this.snapshot;
  }

  getChat(): ChatItem[] {
    return this.chat;
  }

  getKeyFragment(): string {
    return this.key ? keyFromFragmentFragment(this.key) : '';
  }
}

import { b64urlEncode } from './e2ee.js';
import { signalingUrl } from './endpoints.js';
function keyFromFragmentFragment(key: Uint8Array): string {
  return `k=${b64urlEncode(key)}`;
}

export { keyFromFragment };
