/**
 * In-app diagnostics ("Test my setup"). Runs entirely in the browser: nothing
 * leaves the device except a throwaway WebSocket handshake to our own
 * signaling endpoint.
 */
import { apiUrl, signalingUrl } from './endpoints.js';

export type CheckStatus = 'pass' | 'warn' | 'fail' | 'running';

export interface Check {
  id: string;
  label: string;
  status: CheckStatus;
  detail?: string;
}

const makeId = () => Math.floor(Math.random() * 900_000_000) + 100_000_000;

async function checkSecureContext(): Promise<Check> {
  const secure = window.isSecureContext;
  const where = `${location.protocol}//${location.host}`;
  return {
    id: 'secure',
    label: 'Secure context (HTTPS / localhost)',
    status: secure ? 'pass' : 'fail',
    detail: secure
      ? `Running on ${where}`
      : `Camera & microphone are blocked on plain HTTP. Open the HTTPS preview link or localhost (currently ${where}).`,
  };
}

async function checkWebCrypto(): Promise<Check> {
  try {
    const key = await crypto.subtle.importKey('raw', new Uint8Array(32), { name: 'AES-GCM' }, false, [
      'encrypt',
      'decrypt',
    ]);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const data = new TextEncoder().encode('zooom');
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, data);
    await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ct);
    return { id: 'webcrypto', label: 'Web Crypto (AES-GCM-256)', status: 'pass', detail: 'Encrypt/decrypt round-trip OK' };
  } catch {
    return {
      id: 'webcrypto',
      label: 'Web Crypto (AES-GCM-256)',
      status: 'fail',
      detail: 'crypto.subtle unavailable — encryption cannot work',
    };
  }
}

function checkE2EE(): Check {
  const supported =
    typeof (window as unknown as { RTCRtpScriptTransform?: unknown }).RTCRtpScriptTransform === 'function';
  const worker = typeof Worker === 'function' && 'TransformStream' in window;
  if (supported && worker) {
    return {
      id: 'e2ee',
      label: 'End-to-end media encryption',
      status: 'pass',
      detail: 'Insertable streams + worker available',
    };
  }
  return {
    id: 'e2ee',
    label: 'End-to-end media encryption',
    status: 'warn',
    detail: 'This browser has no insertable streams — calls fall back to DTLS-SRTP (encrypted in transit only). Use Chrome/Edge for E2EE.',
  };
}

function checkCodecs(): Check {
  const webm =
    typeof MediaRecorder !== 'undefined' &&
    ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'].some((m) =>
      MediaRecorder.isTypeSupported(m)
    );
  const vp8 =
    typeof RTCRtpSender !== 'undefined' &&
    'getCapabilities' in RTCRtpSender &&
    (RTCRtpSender.getCapabilities('video')?.codecs ?? []).some((codec) => codec.mimeType.includes('VP8'));
  return {
    id: 'codecs',
    label: 'VP8 video + local recording',
    status: webm && vp8 ? 'pass' : webm ? 'warn' : 'fail',
    detail: webm
      ? vp8
        ? 'VP8 codec and MediaRecorder ready'
        : 'Recording OK, VP8 not advertised'
      : 'MediaRecorder missing — local recording disabled',
  };
}

async function checkDevices(): Promise<Check> {
  if (!navigator.mediaDevices?.enumerateDevices) {
    return { id: 'devices', label: 'Camera & microphone', status: 'fail', detail: 'mediaDevices API unavailable' };
  }
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const cams = devices.filter((d) => d.kind === 'videoinput');
    const mics = devices.filter((d) => d.kind === 'audioinput');
    if (cams.length === 0 && mics.length === 0) {
      return {
        id: 'devices',
        label: 'Camera & microphone',
        status: 'warn',
        detail: 'No devices detected (labels may be hidden until access is allowed)',
      };
    }
    return {
      id: 'devices',
      label: 'Camera & microphone',
      status: cams.length > 0 && mics.length > 0 ? 'pass' : 'warn',
      detail: `${cams.length} camera(s), ${mics.length} microphone(s)`,
    };
  } catch (error) {
    return { id: 'devices', label: 'Camera & microphone', status: 'fail', detail: String(error) };
  }
}

async function checkPermission(): Promise<Check> {
  const names: PermissionName[] = ['camera', 'microphone'];
  const statuses = await Promise.all(
    names.map(async (name) => {
      try {
        const status = await navigator.permissions.query({ name });
        return `${name}: ${status.state}`;
      } catch {
        return `${name}: unknown`;
      }
    })
  );
  const blocked = statuses.some((s) => s.includes('denied'));
  return {
    id: 'permission',
    label: 'Browser permissions',
    status: blocked ? 'warn' : 'pass',
    detail: blocked ? `${statuses.join(' · ')} — allow access in the address bar` : statuses.join(' · '),
  };
}

async function checkCapture(): Promise<Check> {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
    const kinds = stream.getTracks().map((t) => t.kind).join(', ');
    stream.getTracks().forEach((t) => t.stop());
    return { id: 'capture', label: 'Live capture test', status: 'pass', detail: `Captured ${kinds}` };
  } catch (error) {
    const name = (error as DOMException)?.name ?? 'error';
    return {
      id: 'capture',
      label: 'Live capture test',
      status: 'warn',
      detail: `${name} — you can still join and receive video; allow access to send yours`,
    };
  }
}

function checkSignaling(): Promise<Check> {
  return new Promise((resolve) => {
    const started = performance.now();
    let settled = false;
    let socket: WebSocket | null = null;
    const done = (check: Check) => {
      if (settled) return;
      settled = true;
      window.clearTimeout(timer);
      try {
        socket?.close();
      } catch {
        /* ignore */
      }
      resolve(check);
    };
    const timer = window.setTimeout(
      () => done({ id: 'signal', label: 'Signaling server (/ws)', status: 'fail', detail: `No response from ${signalingUrl()} in 5s — is the signaling server running?` }),
      5000
    );

    try {
      socket = new WebSocket(signalingUrl());
    } catch (error) {
      done({ id: 'signal', label: 'Signaling server (/ws)', status: 'fail', detail: String(error) });
      return;
    }
    socket.addEventListener('open', () => {
      socket?.send(
        JSON.stringify({ type: 'join', room: String(makeId()), name: 'Self test', muted: true, videoOn: false, e2ee: true })
      );
    });
    socket.addEventListener('message', (event) => {
      try {
        const msg = JSON.parse(String(event.data)) as { type: string };
        if (msg.type === 'joined') {
          const ms = Math.round(performance.now() - started);
          done({ id: 'signal', label: 'Signaling server (/ws)', status: 'pass', detail: `Room created in ${ms} ms` });
        }
      } catch {
        /* ignore */
      }
    });
    socket.addEventListener('error', () =>
      done({ id: 'signal', label: 'Signaling server (/ws)', status: 'fail', detail: 'WebSocket could not connect' })
    );
  });
}

async function checkIce(): Promise<Check> {
  try {
    const response = await fetch(apiUrl('/api/config'), { cache: 'no-store' });
    const config = (await response.json()) as { iceServers: RTCIceServer[]; privacy: { turn: boolean } };
    const count = config.iceServers.length;
    return {
      id: 'ice',
      label: 'ICE / NAT traversal',
      status: count > 0 ? 'pass' : 'warn',
      detail: config.privacy.turn
        ? `${count} ICE server(s), self-hosted TURN configured`
        : count > 0
          ? `${count} STUN server(s), no TURN — strict NATs may fail (set TURN_URLS to fix)`
          : 'No ICE servers (privacy mode) — only same-network peers can connect without TURN',
    };
  } catch {
    return { id: 'ice', label: 'ICE / NAT traversal', status: 'warn', detail: 'Could not load /api/config' };
  }
}

const PLAN: { id: string; label: string }[] = [
  { id: 'secure', label: 'Secure context (HTTPS / localhost)' },
  { id: 'webcrypto', label: 'Web Crypto (AES-GCM-256)' },
  { id: 'e2ee', label: 'End-to-end media encryption' },
  { id: 'codecs', label: 'VP8 video + local recording' },
  { id: 'devices', label: 'Camera & microphone' },
  { id: 'permission', label: 'Browser permissions' },
  { id: 'capture', label: 'Live capture test' },
  { id: 'signal', label: 'Signaling server (/ws)' },
  { id: 'ice', label: 'ICE / NAT traversal' },
];

export async function runSelfTest(onUpdate: (checks: Check[]) => void): Promise<Check[]> {
  const pending: Check[] = PLAN.map((item) => ({ ...item, status: 'running' as const }));
  onUpdate(pending);

  const results: Check[] = [];
  const push = (check: Check) => {
    results.push(check);
    onUpdate([...results, ...PLAN.slice(results.length).map((item) => ({ ...item, status: 'running' as const }))]);
  };

  push(await checkSecureContext());
  push(await checkWebCrypto());
  push(checkE2EE());
  push(checkCodecs());
  push(await checkDevices());
  push(await checkPermission());
  push(await checkCapture());
  push(await checkSignaling());
  push(await checkIce());

  onUpdate(results);
  return results;
}
