/**
 * Media E2EE worker (WebRTC insertable streams).
 *
 * Frame layout
 *   [codec prefix, kept in the clear][12-byte IV][AES-GCM ciphertext + tag]
 *
 * Why the prefix stays plaintext: the receiver's depacketizer decides whether an
 * incoming frame is a keyframe or a delta frame from the first bytes of the
 * payload (VP8/VP9/H.264 frame tag). Encrypting those bytes makes every frame
 * look like a delta frame and the decoder never recovers. The prefix carries no
 * media content — it is a 1-3 byte codec header — so leaving it visible costs
 * nothing in confidentiality while keeping video decodable.
 *
 * Every transform keeps its state in a closure, and each transform gets its own
 * Worker (Chromium binds a transform to the worker it was created with).
 */
type TransformOptions = { operation: 'encrypt' | 'decrypt'; key: Uint8Array };

const IV_BYTES = 12;
const TAG_BYTES = 16;

const keyCache = new Map<string, Promise<CryptoKey>>();

function importKey(bytes: Uint8Array): Promise<CryptoKey> {
  const id = `${Array.from(bytes.slice(0, 8), (b) => b.toString(16)).join('')}:${bytes.length}`;
  let cached = keyCache.get(id);
  if (!cached) {
    cached = crypto.subtle.importKey('raw', bytes as unknown as BufferSource, { name: 'AES-GCM' }, false, [
      'encrypt',
      'decrypt',
    ]);
    keyCache.set(id, cached);
  }
  return cached;
}

/** eslint-disable-next-line @typescript-eslint/no-explicit-any */
const scope = self as any;

scope.onrtctransform = (event: {
  transformer: { options: TransformOptions; readable: ReadableStream; writable: WritableStream };
}) => {
  const { operation, key } = event.transformer.options;
  scope.postMessage({ started: operation });
  const keyPromise = importKey(key);
  let ok = 0;
  let fail = 0;

  const report = setInterval(() => {
    scope.postMessage({ e2ee: { operation, ok, fail } });
    ok = 0;
    fail = 0;
  }, 1000);

  const stream = new TransformStream({
    async transform(frame: { data: ArrayBuffer; type?: string }, controller: { enqueue: (f: unknown) => void }) {
      try {
        const cryptoKey = await keyPromise;
        const source = new Uint8Array(frame.data);
        const prefix = frame.type === undefined ? 1 : 3; // audio: 1 byte, video: 3 bytes

        if (operation === 'encrypt') {
          if (source.byteLength <= prefix) return;
          const iv = crypto.getRandomValues(new Uint8Array(IV_BYTES));
          const sealed = await crypto.subtle.encrypt(
            { name: 'AES-GCM', iv: iv as unknown as BufferSource },
            cryptoKey,
            source.subarray(prefix) as unknown as BufferSource
          );
          const out = new Uint8Array(prefix + IV_BYTES + sealed.byteLength);
          out.set(source.subarray(0, prefix), 0);
          out.set(iv, prefix);
          out.set(new Uint8Array(sealed), prefix + IV_BYTES);
          frame.data = out.buffer;
          ok += 1;
          controller.enqueue(frame);
        } else {
          if (source.byteLength <= prefix + IV_BYTES + TAG_BYTES) return;
          const iv = source.subarray(prefix, prefix + IV_BYTES);
          const body = source.subarray(prefix + IV_BYTES);
          const plain = await crypto.subtle.decrypt(
            { name: 'AES-GCM', iv: iv as unknown as BufferSource },
            cryptoKey,
            body as unknown as BufferSource
          );
          const out = new Uint8Array(prefix + plain.byteLength);
          out.set(source.subarray(0, prefix), 0);
          out.set(new Uint8Array(plain), prefix);
          frame.data = out.buffer;
          ok += 1;
          controller.enqueue(frame);
        }
      } catch {
        fail += 1; // wrong key or tampered frame -> dropped
      }
    },
  });

  event.transformer.readable
    .pipeThrough(stream as unknown as TransformStream)
    .pipeTo(event.transformer.writable)
    .catch(() => undefined)
    .finally(() => clearInterval(report));
};
