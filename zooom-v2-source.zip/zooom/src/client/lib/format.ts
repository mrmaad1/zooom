export const digits = (value: string | null | undefined): string => String(value ?? '').replace(/\D/g, '');

export const formatMeetingId = (value: string | null | undefined): string => {
  const d = digits(value);
  return [d.slice(0, 3), d.slice(3, 7), d.slice(7, 11)].filter(Boolean).join(' ');
};

export function newMeetingId(): string {
  let id = String(Math.floor(1 + Math.random() * 9));
  while (id.length < 11) id += Math.floor(Math.random() * 10);
  return id;
}

export const initials = (name: string | null | undefined): string => {
  const parts = String(name || 'You').trim().split(/\s+/);
  return ((parts[0]?.[0] ?? 'Y') + (parts[1]?.[0] ?? '')).toUpperCase();
};

export const clockTime = (ts: number): string =>
  new Date(ts).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

export function duration(ms: number): string {
  const total = Math.floor(ms / 1000);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export const sameOriginInvite = (room: string, keyFragment: string): string =>
  `${location.origin}${location.pathname}?room=${digits(room)}${keyFragment ? `#${keyFragment}` : ''}`;
