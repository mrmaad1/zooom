/**
 * Local capture (mic / camera / screen) behind a tiny class so React only sees
 * immutable snapshots. Nothing is recorded or uploaded here.
 */
export type MediaState = {
  micOn: boolean;
  camOn: boolean;
  sharing: boolean;
  hasMic: boolean;
  hasCam: boolean;
  ready: boolean;
  error: string | null;
};

export const initialMediaState: MediaState = {
  micOn: false,
  camOn: false,
  sharing: false,
  hasMic: false,
  hasCam: false,
  ready: false,
  error: null,
};

const audioConstraints = (deviceId?: string | null): MediaTrackConstraints => ({
  echoCancellation: true,
  noiseSuppression: true,
  autoGainControl: true,
  ...(deviceId ? { deviceId: { exact: deviceId } } : {}),
});

const videoConstraints = (deviceId?: string | null): MediaTrackConstraints => ({
  width: { ideal: 1280 },
  height: { ideal: 720 },
  ...(deviceId ? { deviceId: { exact: deviceId } } : {}),
});

export class LocalMedia {
  stream: MediaStream = new MediaStream();
  mic: MediaStreamTrack | null = null;
  cam: MediaStreamTrack | null = null;
  screen: MediaStreamTrack | null = null;
  private micOn = true;
  private camOn = true;
  private sharing = false;
  private deviceId: { audio: string | null; video: string | null } = { audio: null, video: null };
  onChange: (state: MediaState) => void = () => {};
  onTrackReplaced: () => void = () => {};
  private silentAudio: MediaStreamTrack | null = null;
  private blankVideo: MediaStreamTrack | null = null;

  state(): MediaState {
    return {
      micOn: this.micOn && !!this.mic,
      camOn: this.camOn && !!this.cam,
      sharing: this.sharing,
      hasMic: !!this.mic,
      hasCam: !!this.cam,
      ready: !!this.mic || !!this.cam,
      error: null,
    };
  }

  private emit() {
    this.onChange(this.state());
  }

  /* ---------------- acquire ---------------- */
  async ensure(): Promise<void> {
    if (this.mic || this.cam) return;
    if (!navigator.mediaDevices?.getUserMedia) {
      this.onChange({ ...this.state(), ready: true, error: 'unsupported' });
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: audioConstraints(this.deviceId.audio),
        video: videoConstraints(this.deviceId.video),
      });
      this.absorb(stream);
    } catch {
      // degrade gracefully: audio-only -> video-only -> none
      try {
        const audio = await navigator.mediaDevices.getUserMedia({ audio: audioConstraints(this.deviceId.audio) });
        this.absorb(audio);
      } catch {
        try {
          const video = await navigator.mediaDevices.getUserMedia({ video: videoConstraints(this.deviceId.video) });
          this.absorb(video);
        } catch {
          this.onChange({ ...this.state(), ready: true, error: 'denied' });
          return;
        }
      }
    }
    this.emit();
  }

  private absorb(stream: MediaStream) {
    stream.getAudioTracks().forEach((t) => {
      this.mic = t;
      this.stream.addTrack(t);
      t.enabled = this.micOn;
      t.addEventListener('ended', () => {
        this.mic = null;
        this.emit();
      });
    });
    stream.getVideoTracks().forEach((t) => {
      this.cam = t;
      this.stream.addTrack(t);
      t.enabled = this.camOn;
      t.addEventListener('ended', () => {
        this.cam = null;
        this.emit();
      });
    });
  }

  async acquireMic(): Promise<boolean> {
    if (this.mic) return true;
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: audioConstraints(this.deviceId.audio) });
      this.absorb(s);
      this.micOn = true;
      this.emit();
      this.onTrackReplaced();
      return true;
    } catch {
      return false;
    }
  }

  async acquireCam(): Promise<boolean> {
    if (this.cam) return true;
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: videoConstraints(this.deviceId.video) });
      this.absorb(s);
      this.camOn = true;
      this.emit();
      this.onTrackReplaced();
      return true;
    } catch {
      return false;
    }
  }

  /* ---------------- toggles ---------------- */
  setMic(on: boolean): boolean {
    if (on && !this.mic) return false;
    this.micOn = on;
    if (this.mic) this.mic.enabled = on;
    this.emit();
    return true;
  }

  setCam(on: boolean): boolean {
    if (on && !this.cam) return false;
    this.camOn = on;
    if (this.cam) this.cam.enabled = on;
    this.emit();
    return true;
  }

  /* ---------------- screen share ---------------- */
  async startScreen(): Promise<boolean> {
    if (!navigator.mediaDevices?.getDisplayMedia) return false;
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: { ideal: 15, max: 30 } },
        audio: false,
      });
      const track = stream.getVideoTracks()[0];
      if (!track) return false;
      this.screen = track;
      this.sharing = true;
      track.addEventListener('ended', () => this.stopScreen());
      this.onTrackReplaced();
      this.emit();
      return true;
    } catch {
      return false;
    }
  }

  stopScreen() {
    if (!this.sharing) return;
    this.sharing = false;
    this.screen?.stop();
    this.screen = null;
    this.onTrackReplaced();
    this.emit();
  }

  /* ---------------- outgoing tracks ---------------- */
  outgoingAudio(): MediaStreamTrack | null {
    if (this.mic) return this.mic;
    if (!this.silentAudio) {
      try {
        const ctx = new AudioContext();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        gain.gain.value = 0.0001;
        const dest = ctx.createMediaStreamDestination();
        osc.connect(gain).connect(dest);
        osc.start();
        this.silentAudio = dest.stream.getAudioTracks()[0] ?? null;
      } catch {
        this.silentAudio = null;
      }
    }
    return this.silentAudio;
  }

  outgoingVideo(): MediaStreamTrack | null {
    if (this.sharing && this.screen) return this.screen;
    if (this.cam) return this.cam;
    if (!this.blankVideo) {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 32;
        canvas.height = 32;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#121212';
          ctx.fillRect(0, 0, 32, 32);
        }
        this.blankVideo = canvas.captureStream(2).getVideoTracks()[0] ?? null;
      } catch {
        this.blankVideo = null;
      }
    }
    return this.blankVideo;
  }

  async switchDevice(kind: 'audio' | 'video', deviceId: string) {
    this.deviceId[kind === 'audio' ? 'audio' : 'video'] = deviceId;
    try {
      const stream = await navigator.mediaDevices.getUserMedia(
        kind === 'audio'
          ? { audio: audioConstraints(deviceId) }
          : { video: videoConstraints(deviceId) }
      );
      if (kind === 'audio') {
        const track = stream.getAudioTracks()[0];
        if (!track) return;
        this.mic?.stop();
        if (this.mic) this.stream.removeTrack(this.mic);
        this.mic = track;
        this.stream.addTrack(track);
        track.enabled = this.micOn;
      } else {
        const track = stream.getVideoTracks()[0];
        if (!track) return;
        this.cam?.stop();
        if (this.cam) this.stream.removeTrack(this.cam);
        this.cam = track;
        this.stream.addTrack(track);
        track.enabled = this.camOn;
      }
      this.onTrackReplaced();
      this.emit();
    } catch {
      /* keep current device */
    }
  }

  stop() {
    this.stream.getTracks().forEach((t) => t.stop());
    this.screen?.stop();
    this.screen = null;
    this.sharing = false;
    this.mic = null;
    this.cam = null;
    this.stream = new MediaStream();
    this.emit();
  }
}
