/**
 * End-to-end encryption.
 *
 * The meeting key is 256-bit and lives ONLY in the URL fragment (`#k=…`), which
 * browsers never send to servers. It is used for:
 *   - media  : E2EE via insertable streams (RTCRtpScriptTransform + worker)
 *   - chat   : AES-GCM per message, encrypted before it reaches the server
 *
 * If a browser has no insertable-streams support, media falls back to the
 * browser's own DTLS-SRTP hop encryption only — the UI tells the user that.
 */

const encoder = new TextEncoder();
const decoder = new TextDecoder();

export const KEY_BYTES = 32;

/* typed surface of the APIs we feature-detect (not in TS DOM lib yet) */
type RtpScriptTransform = { new (worker: Worker, options?: unknown): unknown };
declare global {
  interface Window {
    RTCRtpScriptTransform?: RtpScriptTransform;
  }
}

export function isMediaE2EESupported(): boolean {
  return typeof window !== 'undefined' && typeof window.RTCRtpScriptTransform === 'function';
}

export function randomKey(): Uint8Array {
  const key = new Uint8Array(KEY_BYTES);
  crypto.getRandomValues(key);
  return key;
}

export function b64urlEncode(bytes: Uint8Array): string {
  let s = '';
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function b64urlDecode(value: string): Uint8Array | null {
  try {
    const padded = value.replace(/-/g, '+').replace(/_/g, '/');
    const raw = atob(padded + '='.repeat((4 - (padded.length % 4)) % 4));
    const out = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out.length === KEY_BYTES ? out : null;
  } catch {
    return null;
  }
}

/** read `#k=…` (also tolerates a pasted full invite link) */
export function keyFromFragment(hash: string): Uint8Array | null {
  const m = /(?:^#|&)k=([A-Za-z0-9_-]{20,})/.exec(hash);
  return m?.[1] ? b64urlDecode(m[1]) : null;
}

export function keyFromAnyInput(input: string): Uint8Array | null {
  const trimmed = input.trim();
  if (!trimmed) return null;
  const direct = b64urlDecode(trimmed);
  if (direct) return direct;
  const fromHash = keyFromFragment(trimmed.includes('#') ? trimmed.slice(trimmed.indexOf('#')) : '');
  if (fromHash) return fromHash;
  const fromQuery = /[#?&]k=([A-Za-z0-9_-]{20,})/.exec(trimmed);
  return fromQuery?.[1] ? b64urlDecode(fromQuery[1]) : null;
}

export function writeKeyToFragment(key: Uint8Array | null, room: string) {
  const url = new URL(location.href);
  url.searchParams.set('room', room);
  url.hash = key ? `k=${b64urlEncode(key)}` : '';
  history.replaceState({}, '', url.toString());
}

/* ------------------------------------------------------------------ */
/* chat: AES-GCM                                                       */
/* ------------------------------------------------------------------ */
const keyCache = new WeakMap<Uint8Array, Promise<CryptoKey>>();

function cryptoKey(keyBytes: Uint8Array): Promise<CryptoKey> {
  let cached = keyCache.get(keyBytes);
  if (!cached) {
    cached = crypto.subtle.importKey('raw', keyBytes as unknown as BufferSource, { name: 'AES-GCM' }, false, [
      'encrypt',
      'decrypt',
    ]);
    keyCache.set(keyBytes, cached);
  }
  return cached;
}

export interface Sealed {
  ct: string;
  iv: string;
}

export async function sealText(text: string, keyBytes: Uint8Array): Promise<Sealed> {
  const key = await cryptoKey(keyBytes);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: iv as unknown as BufferSource },
    key,
    encoder.encode(text) as unknown as BufferSource
  );
  return { ct: b64urlEncode(new Uint8Array(ct)), iv: b64urlEncode(iv) };
}

export async function openText(sealed: Sealed, keyBytes: Uint8Array | null): Promise<string | null> {
  if (!keyBytes) return null;
  try {
    const key = await cryptoKey(keyBytes);
    const iv = b64urlDecodeAny(sealed.iv);
    const data = b64urlDecodeAny(sealed.ct);
    if (!iv || !data) return null;
    const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv as unknown as BufferSource }, key, data as unknown as BufferSource);
    return decoder.decode(plain);
  } catch {
    return null;
  }
}

function b64urlDecodeAny(value: string): Uint8Array | null {
  try {
    const padded = value.replace(/-/g, '+').replace(/_/g, '/');
    const raw = atob(padded + '='.repeat((4 - (padded.length % 4)) % 4));
    const out = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  } catch {
    return null;
  }
}

/* ------------------------------------------------------------------ */
/* media: insertable streams                                           */
/* ------------------------------------------------------------------ */
/**
 * One Worker per transform: Chromium ties a transform to the worker it was
 * created with, so sharing a single worker between the encrypting senders and
 * the decrypting receivers makes only the first transform run.
 */
function createWorker(): Worker {
  const w = new Worker(new URL('./e2ee.worker.ts', import.meta.url), { type: 'module' });
  w.addEventListener('error', (event: ErrorEvent) => {
    const log = ((window as unknown as { __e2eeAttach?: string[] }).__e2eeAttach ??= []);
    log.push(`worker error: ${event.message || 'unknown'}`);
  });
  // lightweight counters (no media, no keys) — exposed for debugging in the console
  w.addEventListener('message', (event: MessageEvent) => {
    const data = event.data as { e2ee?: { operation: string; ok: number; fail: number } };
    if (!data.e2ee) return;
    const stats = ((window as unknown as { __e2eeStats?: Record<string, { ok: number; fail: number }> }).__e2eeStats ??= {});
    const bucket = (stats[data.e2ee.operation] ??= { ok: 0, fail: 0 });
    bucket.ok += data.e2ee.ok;
    bucket.fail += data.e2ee.fail;
  });
  return w;
}

/** Attach an encrypting transform to an outgoing sender (no-op if unsupported). */
const sendersDone = new WeakSet<RTCRtpSender>();
const receiversDone = new WeakSet<RTCRtpReceiver>();

export function encryptSender(sender: RTCRtpSender, keyBytes: Uint8Array): boolean {
  if (sendersDone.has(sender)) return true;
  const Transform = window.RTCRtpScriptTransform;
  if (!Transform || !('transform' in sender)) return false;
  try {
    (sender as unknown as { transform: unknown }).transform = new Transform(createWorker(), {
      operation: 'encrypt',
      key: keyBytes,
    });
    sendersDone.add(sender);
    return true;
  } catch {
    return false;
  }
}

/** Attach a decrypting transform to an incoming receiver (no-op if unsupported). */
export function decryptReceiver(receiver: RTCRtpReceiver, keyBytes: Uint8Array): boolean {
  if (receiversDone.has(receiver)) return true;
  const Transform = window.RTCRtpScriptTransform;
  if (!Transform || !('transform' in receiver)) return false;
  try {
    (receiver as unknown as { transform: unknown }).transform = new Transform(createWorker(), {
      operation: 'decrypt',
      key: keyBytes,
    });
    receiversDone.add(receiver);
    return true;
  } catch {
    return false;
  }
}
