import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Sprite } from './components/Icons.js';
import { AppFrame, Rail, TopBar, type Tab } from './components/Shell.js';
import { Home } from './components/Home.js';
import { MeetingsTab, MoreTab, RecordingsTab } from './components/Meetings.js';
import { Prejoin } from './components/Prejoin.js';
import { MeetingScreen } from './components/Meeting.js';
import { ScheduleModal, SettingsModal, ProfileModal, RenameModal, ParticipantModal, InfoModal, UnlockModal } from './components/modals.js';
import { SelfTestModal } from './components/SelfTest.js';
import { Btn, Modal, Toasts } from './components/ui.js';
import { LocalMedia, initialMediaState, type MediaState } from './lib/media.js';
import { CallSession, type CallSnapshot, type ChatItem } from './lib/call.js';
import { LocalRecorder, downloadBlob } from './lib/recorder.js';
import { b64urlEncode, isMediaE2EESupported, keyFromAnyInput, keyFromFragment, randomKey, writeKeyToFragment } from './lib/e2ee.js';
import { digits, duration, formatMeetingId, newMeetingId } from './lib/format.js';
import { storage, type RecordingEntry, type RecentMeeting, type ScheduledMeeting } from './lib/storage.js';
import type { ClientConfig } from '../shared/protocol.js';
import { apiUrl } from './lib/endpoints.js';

type Screen = 'home' | 'prejoin' | 'meeting';
type ModalState =
  | null
  | 'schedule'
  | 'settings'
  | 'profile'
  | 'rename'
  | 'info'
  | 'unlock'
  | 'selftest'
  | { kind: 'participant'; id: string; name: string };

interface Toast {
  id: number;
  text: string;
  kind?: string;
}

interface PrejoinState {
  room: string | null;
  mode: 'new' | 'join' | 'pmi';
  share: boolean;
  key: Uint8Array | null;
  needsKey: boolean;
  error: string | null;
}

const DEFAULT_CONFIG: ClientConfig = {
  maxParticipants: 24,
  iceServers: [],
  privacy: { publicStun: true, turn: false, e2eeRequired: false },
  limits: { chatBytes: 8192, nameChars: 42 },
  version: '2.0.0',
};

export default function App() {
  /* ---------------- persistent, local-only state ---------------- */
  const [name, setName] = useState(() => storage.profileName());
  const [pmi] = useState(() => {
    const existing = storage.pmi();
    if (existing) return existing;
    const generated = newMeetingId();
    storage.setPmi(generated);
    return generated;
  });
  const [meetings, setMeetings] = useState<ScheduledMeeting[]>(() => storage.meetings());
  const [recents, setRecents] = useState<RecentMeeting[]>(() => storage.recents());
  const [recordings, setRecordings] = useState<RecordingEntry[]>(() => storage.recordings());

  /* ---------------- ui state ---------------- */
  const [screen, setScreen] = useState<Screen>('home');
  const [tab, setTab] = useState<Tab>('home');
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState<ModalState>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [floats, setFloats] = useState<{ id: number; emoji: string; left: number }[]>([]);
  const [privacyMode, setPrivacyMode] = useState(false);
  const toastId = useRef(0);

  const toast = useCallback((text: string, kind?: string) => {
    const id = ++toastId.current;
    setToasts((list) => [...list, { id, text, kind }]);
    window.setTimeout(() => setToasts((list) => list.filter((t) => t.id !== id)), 2800);
  }, []);

  /* ---------------- config from server ---------------- */
  const [config, setConfig] = useState<ClientConfig>(DEFAULT_CONFIG);
  useEffect(() => {
    let cancelled = false;
    fetch(apiUrl('/api/config'), { cache: 'no-store' })
      .then((r) => r.json() as Promise<ClientConfig>)
      .then((cfg) => {
        if (!cancelled) setConfig(cfg);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  /* ---------------- media ---------------- */
  const media = useMemo(() => new LocalMedia(), []);
  const [mediaState, setMediaState] = useState<MediaState>(initialMediaState);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);

  /* ---------------- call engine ---------------- */
  const call = useMemo(() => new CallSession(), []);
  const [snapshot, setSnapshot] = useState<CallSnapshot>(() => call.getSnapshot());
  const [chat, setChat] = useState<ChatItem[]>([]);
  const [prejoin, setPrejoin] = useState<PrejoinState>({
    room: null,
    mode: 'new',
    share: false,
    key: null,
    needsKey: false,
    error: null,
  });

  const recorder = useMemo(() => new LocalRecorder(), []);
  const [recording, setRecording] = useState(false);
  const [recElapsed, setRecElapsed] = useState('00:00');

  /* ---------------- wiring ---------------- */
  useEffect(() => {
    media.onChange = (state) => setMediaState(state);
    media.onTrackReplaced = () => call.rewireTracks();
    call.onSnapshot = (next) => setSnapshot(next);
    call.onChat = (items) => setChat(items);
    call.onEvent = (event) => {
      if (event.type === 'reaction') {
        setFloats((list) => [...list, { id: Date.now() + Math.random(), emoji: event.emoji, left: 12 + Math.random() * 70 }]);
        window.setTimeout(() => setFloats((list) => list.slice(1)), 3400);
      } else if (event.type === 'mute-request') {
        media.setMic(false);
        toast('You were muted by the host');
      } else if (event.type === 'removed') {
        toast('You were removed from the meeting');
        setScreen('home');
      } else if (event.type === 'error') {
        toast(event.message);
      }
    };
  }, [media, call, toast]);

  /* keep the self tile in sync with the real stream/track set */
  useEffect(() => {
    setLocalStream(media.stream);
  }, [media, mediaState.sharing, mediaState.hasCam, mediaState.hasMic]);

  /* broadcast mute/camera/share state to the room */
  useEffect(() => {
    if (screen !== 'meeting' || snapshot.status !== 'joined') return;
    call.publishState({ muted: !mediaState.micOn, videoOn: mediaState.camOn, sharing: mediaState.sharing });
  }, [call, mediaState.micOn, mediaState.camOn, mediaState.sharing, screen, snapshot.status]);

  useEffect(() => {
    recorder.onTick = (elapsed) => setRecElapsed(duration(elapsed));
  }, [recorder]);

  /* encrypted room but no key ? -> ask for the invite link */
  useEffect(() => {
    if (screen === 'meeting' && snapshot.encryptedRoom && !snapshot.hasKey) setModal('unlock');
  }, [screen, snapshot.encryptedRoom, snapshot.hasKey]);

  /* friendlier errors from the server */
  useEffect(() => {
    if (snapshot.status !== 'error') return;
    if (snapshot.error === 'room-full') {
      toast(`This meeting is full (${snapshot.maxParticipants} max)`);
      setScreen('home');
    } else if (snapshot.error === 'offline') {
      toast('Connection lost — check your network');
    }
  }, [snapshot.status, snapshot.error, snapshot.maxParticipants, toast]);

  /* deep link: ?room=… #k=… */
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const room = digits(params.get('room'));
    if (room.length < 4) return;
    const key = keyFromFragment(location.hash);
    setPrejoin({ room, mode: 'join', share: false, key, needsKey: false, error: null });
    setScreen('prejoin');
    void media.ensure();
    window.history.replaceState({}, '', location.pathname);
  }, [media]);

  /* Ctrl+E focuses search */
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'e') {
        event.preventDefault();
        setTab('meetings');
        document.querySelector<HTMLInputElement>('.wsearch input')?.focus();
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);

  /* ---------------- helpers ---------------- */
  const inviteLink = useCallback(
    (room: string) => {
      const key = prejoin.key ?? keyFromFragment(location.hash);
      return `${location.origin}${location.pathname}?room=${digits(room)}${key ? `#k=${b64urlEncode(key)}` : ''}`;
    },
    [prejoin.key]
  );

  const copy = useCallback(
    async (text: string, message: string) => {
      try {
        await navigator.clipboard.writeText(text);
        toast(message, 'good');
      } catch {
        toast('Copy failed — select the text manually');
      }
    },
    [toast]
  );

  const iceForJoin = useCallback(
    () => ({ ...config, iceServers: privacyMode ? config.iceServers.filter((s) => String(s.urls).includes('turn')) : config.iceServers }),
    [config, privacyMode]
  );

  /* ---------------- navigation / flow ---------------- */
  const goHome = useCallback(() => {
    call.leave({ silent: true });
    media.stop();
    setScreen('home');
    setPrejoin((p) => ({ ...p, key: null, needsKey: false, error: null }));
    writeKeyToFragment(null, '');
    window.history.replaceState({}, '', location.pathname);
  }, [call, media]);

  const beginNew = useCallback(
    (variant: 'video' | 'novideo' | 'share' = 'video') => {
      const room = newMeetingId();
      const key = randomKey();
      writeKeyToFragment(key, room);
      setPrejoin({ room, mode: 'new', share: variant === 'share', key, needsKey: false, error: null });
      setScreen('prejoin');
      void (async () => {
        await media.ensure();
        if (variant === 'novideo') media.setCam(false);
      })();
    },
    [media]
  );

  const beginJoin = useCallback(
    (room?: string) => {
      const key = keyFromFragment(location.hash);
      setPrejoin({ room: room ?? null, mode: 'join', share: false, key, needsKey: false, error: null });
      setScreen('prejoin');
      void media.ensure();
    },
    [media]
  );

  const beginPmi = useCallback(() => {
    const key = randomKey();
    writeKeyToFragment(key, pmi);
    setPrejoin({ room: pmi, mode: 'pmi', share: false, key, needsKey: false, error: null });
    setScreen('prejoin');
    void media.ensure();
  }, [media, pmi]);

  const joinNow = useCallback(
    async (roomInput: string, displayName: string) => {
      const finalName = displayName.trim() || 'Guest';
      const isNew = prejoin.mode !== 'join';
      const room = isNew ? prejoin.room ?? newMeetingId() : digits(roomInput);
      if (room.length < 4) {
        setPrejoin((p) => ({ ...p, error: 'Enter a valid meeting ID (at least 4 digits).' }));
        return;
      }
      setName(finalName);
      storage.setProfileName(finalName);
      writeKeyToFragment(prejoin.key, room);
      setScreen('meeting');
      await call.join({
        room,
        name: finalName,
        key: prejoin.key,
        media,
        config: iceForJoin(),
        muted: !mediaState.micOn,
        videoOn: mediaState.camOn,
      });
      const entry: RecentMeeting = { room, title: isNew ? 'Instant meeting' : 'Joined meeting', ts: Date.now() };
      const next = [entry, ...recents.filter((r) => r.room !== room)].slice(0, 12);
      setRecents(next);
      storage.setRecents(next);
      if (prejoin.share) {
        window.setTimeout(() => {
          void media.startScreen().then((ok) => {
            if (ok) toast('You are presenting your screen');
          });
        }, 700);
      }
    },
    [call, iceForJoin, media, mediaState.camOn, mediaState.micOn, prejoin, recents, toast]
  );

  const leaveMeeting = useCallback(() => {
    void (async () => {
      if (recorder.recording) await stopRecording();
      call.leave();
      media.stopScreen();
      media.stop();
      setScreen('home');
      toast('You left the meeting');
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [call, media, recorder, toast]);

  /* ---------------- meeting actions ---------------- */
  const toggleMic = useCallback(async () => {
    if (mediaState.micOn) {
      media.setMic(false);
      return;
    }
    if (!mediaState.hasMic) {
      const ok = await media.acquireMic();
      if (!ok) {
        toast('Microphone unavailable — check browser permissions');
        return;
      }
    }
    media.setMic(true);
  }, [media, mediaState.hasMic, mediaState.micOn, toast]);

  const toggleCam = useCallback(async () => {
    if (mediaState.camOn) {
      media.setCam(false);
      return;
    }
    if (!mediaState.hasCam) {
      const ok = await media.acquireCam();
      if (!ok) {
        toast('Camera unavailable — check browser permissions');
        return;
      }
    }
    media.setCam(true);
  }, [media, mediaState.camOn, mediaState.hasCam, toast]);

  const toggleShare = useCallback(async () => {
    if (mediaState.sharing) {
      media.stopScreen();
      toast('Screen sharing stopped');
      return;
    }
    const ok = await media.startScreen();
    if (ok) toast('You are presenting your screen');
  }, [media, mediaState.sharing, toast]);

  const stopRecording = useCallback(async () => {
    const result = await recorder.stop();
    setRecording(false);
    if (!result) return;
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    const filename = `zooom-${snapshot.room ?? 'meeting'}-${stamp}.webm`;
    downloadBlob(result.blob, filename);
    const entry: RecordingEntry = { name: filename, ts: Date.now(), size: `${(result.blob.size / 1_048_576).toFixed(1)} MB` };
    const next = [entry, ...recordings].slice(0, 20);
    setRecordings(next);
    storage.setRecordings(next);
    toast('Recording saved to your downloads', 'good');
  }, [recorder, recordings, snapshot.room, toast]);

  const toggleRecording = useCallback(async () => {
    if (recorder.recording) {
      await stopRecording();
      return;
    }
    const started = await recorder.start(
      () => Array.from(document.querySelectorAll<HTMLVideoElement>('#video-grid video')),
      () => [media.stream, ...Object.values(snapshot.streams)]
    );
    if (!started) {
      toast('Recording is not supported in this browser');
      return;
    }
    setRecording(true);
    toast('Recording started — saved locally when you stop');
  }, [media.stream, recorder, snapshot.streams, stopRecording, toast]);

  const isHost = !!snapshot.selfId && snapshot.hostId === snapshot.selfId;
  const hostName = snapshot.participants.find((p) => p.isHost)?.name ?? '';

  const unlockWithKey = useCallback(
    (input: string) => {
      const key = keyFromAnyInput(input);
      if (!key) {
        toast('That does not look like a valid invite link or key');
        return;
      }
      const room = snapshot.room ?? prejoin.room ?? '';
      writeKeyToFragment(key, room);
      setModal(null);
      toast('Key accepted — reloading encrypted session');
      window.setTimeout(() => location.reload(), 400);
    },
    [prejoin.room, snapshot.room, toast]
  );

  /* ---------------- render ---------------- */
  const e2eeState = isMediaE2EESupported() ? ('on' as const) : ('unsupported' as const);

  return (
    <>
      <Sprite />

      {screen === 'home' ? (
        <AppFrame
          top={
            <TopBar
              name={name}
              search={search}
              onSearch={(value) => {
                setSearch(value);
                if (value) setTab('meetings');
              }}
              onBell={() => {
                if (recents.length === 0) {
                  toast('No notifications yet');
                  return;
                }
                setTab('meetings');
                toast(`${recents.length} recent meeting${recents.length === 1 ? '' : 's'}`);
              }}
              onProfile={() => setModal('profile')}
              onPlus={() => setModal('schedule')}
              onRoom={beginPmi}
              e2ee={e2eeState}
            />
          }
          rail={<Rail tab={tab} onTab={setTab} onSettings={() => setModal('settings')} />}
        >
          {tab === 'home' ? (
            <Home
              name={name}
              meetings={meetings}
              e2eeSupported={isMediaE2EESupported()}
              onNew={beginNew}
              onJoin={() => beginJoin()}
              onSchedule={() => setModal('schedule')}
              onShare={() => beginNew('share')}
              onStartMeeting={(meeting) => beginJoin(meeting.room)}
              onCopyMeeting={(meeting) =>
                void copy(`${meeting.title}\n${inviteLink(meeting.room)}`, 'Invite copied to clipboard')
              }
              onViewAll={() => setTab('meetings')}
            />
          ) : null}

          {tab === 'meetings' ? (
            <MeetingsTab
              meetings={meetings}
              recents={recents}
              pmi={pmi}
              search={search}
              onStart={(meeting) => beginJoin(meeting.room)}
              onCopy={(meeting) => void copy(inviteLink(meeting.room), 'Invite copied')}
              onDelete={(id) => {
                const next = meetings.filter((m) => m.id !== id);
                setMeetings(next);
                storage.setMeetings(next);
                toast('Meeting deleted');
              }}
              onRejoin={(recent) => beginJoin(recent.room)}
              onSchedule={() => setModal('schedule')}
              onStartPmi={beginPmi}
              onCopyPmi={() => void copy(inviteLink(pmi), 'Personal invite copied')}
            />
          ) : null}

          {tab === 'recordings' ? (
            <RecordingsTab
              recordings={recordings}
              onRemove={(index) => {
                const next = recordings.filter((_, i) => i !== index);
                setRecordings(next);
                storage.setRecordings(next);
              }}
            />
          ) : null}

          {tab === 'more' ? (
            <MoreTab
              config={config}
              onSelfTest={() => setModal('selftest')}
              onSettings={() => setModal('settings')}
              onJoin={() => beginJoin()}
              onSchedule={() => setModal('schedule')}
            />
          ) : null}
        </AppFrame>
      ) : null}

      {screen === 'prejoin' ? (
        <Prejoin
          room={prejoin.room}
          mode={prejoin.mode}
          name={name}
          mediaState={mediaState}
          stream={media.stream}
          e2eeSupported={isMediaE2EESupported()}
          needsKey={prejoin.needsKey}
          error={prejoin.error}
          onNameChange={setName}
          onToggleMic={() => void toggleMic()}
          onToggleCam={() => void toggleCam()}
          onSettings={() => setModal('settings')}
          onJoin={(roomInput, displayName) => void joinNow(roomInput, displayName)}
          onUnlock={unlockWithKey}
          onHome={goHome}
        />
      ) : null}

      {screen === 'meeting' ? (
        <MeetingScreen
          snapshot={snapshot}
          room={snapshot.room ?? prejoin.room ?? ''}
          chat={chat}
          mediaState={mediaState}
          localStream={localStream}
          isHost={isHost}
          recording={recording}
          recElapsed={recElapsed}
          e2eeSupported={isMediaE2EESupported()}
          floats={floats}
          onToggleMic={() => void toggleMic()}
          onToggleCam={() => void toggleCam()}
          onShareToggle={() => void toggleShare()}
          onHand={() => call.raiseHand(!snapshot.participants.find((p) => p.self)?.hand)}
          onLeave={leaveMeeting}
          onChat={(text, to) => void call.sendChat(text, to)}
          onReaction={(emoji) => call.reaction(emoji)}
          onCopyInvite={() => void copy(inviteLink(snapshot.room ?? ''), 'Invite link copied — send it to anyone')}
          onInfo={() => setModal('info')}
          onSettings={() => setModal('settings')}
          onRecord={() => void toggleRecording()}
          onRename={() => setModal('rename')}
          onMuteAll={() => {
            call.muteAll();
            toast('Muted all participants');
          }}
          onAskMute={(id, participantName) => setModal({ kind: 'participant', id, name: participantName })}
        />
      ) : null}

      {/* ---------------- modals ---------------- */}
      {modal === 'schedule' ? (
        <ScheduleModal
          onClose={() => setModal(null)}
          onSave={(meeting) => {
            const next = [...meetings, { ...meeting, id: `m${Date.now()}` }];
            setMeetings(next);
            storage.setMeetings(next);
            void copy(
              `${meeting.title}\n${location.origin}${location.pathname}?room=${meeting.room}#k=${b64urlEncode(randomKey())}`,
              'Meeting scheduled — invite copied'
            );
            setModal(null);
            setTab('meetings');
          }}
        />
      ) : null}

      {modal === 'settings' ? (
        <SettingsModal
          media={media}
          mediaState={mediaState}
          config={config}
          privacyMode={privacyMode}
          onPrivacyMode={setPrivacyMode}
          onClose={() => setModal(null)}
        />
      ) : null}

      {modal === 'profile' ? (
        <ProfileModal
          name={name}
          onClose={() => setModal(null)}
          onSave={(value) => {
            setName(value);
            storage.setProfileName(value);
            if (screen === 'meeting' && value) call.rename(value);
            setModal(null);
          }}
        />
      ) : null}

      {modal === 'rename' ? (
        <RenameModal
          name={name}
          onClose={() => setModal(null)}
          onSave={(value) => {
            setName(value);
            storage.setProfileName(value);
            call.rename(value);
            setModal(null);
          }}
        />
      ) : null}

      {modal === 'info' ? (
        <InfoModal
          room={snapshot.room ?? ''}
          invite={inviteLink(snapshot.room ?? '')}
          hostName={hostName}
          count={snapshot.participants.length}
          onClose={() => setModal(null)}
          onCopy={() => void copy(inviteLink(snapshot.room ?? ''), 'Invite link copied')}
        />
      ) : null}

      {modal === 'unlock' ? <UnlockModal onSubmit={unlockWithKey} onLeave={goHome} /> : null}

      {modal === 'selftest' ? <SelfTestModal onClose={() => setModal(null)} /> : null}

      {modal && typeof modal === 'object' && modal.kind === 'participant' ? (
        <ParticipantModal
          name={modal.name}
          onClose={() => setModal(null)}
          onAskMute={() => {
            call.askMute(modal.id);
            setModal(null);
            toast('Mute request sent');
          }}
          onRemove={() => {
            call.remove(modal.id);
            setModal(null);
            toast(`${modal.name} was removed`);
          }}
        />
      ) : null}

      {/* offline / error fallback */}
      {screen === 'meeting' && snapshot.status === 'error' && snapshot.error === 'bad-room' ? (
        <Modal
          title="Could not join"
          onClose={goHome}
          footer={<Btn kind="primary" onClick={goHome}>Back to home</Btn>}
        >
          <p className="hint">The meeting link is invalid or the room expired. Ask the host for a fresh invite link.</p>
        </Modal>
      ) : null}

      <Toasts items={toasts} />

      {/* keep the meeting id in the tab title, like Zoom */}
      <title>{screen === 'meeting' ? `${formatMeetingId(snapshot.room ?? '')} — Zooom` : 'Zooom — Free Video Meetings'}</title>
    </>
  );
}
