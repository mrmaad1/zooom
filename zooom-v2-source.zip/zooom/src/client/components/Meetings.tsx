import { Icon } from './Icons.js';
import { Btn, Empty } from './ui.js';
import { RecentRow, RecordingRow, ScheduledRow } from './MeetingRow.js';
import type { RecentMeeting, RecordingEntry, ScheduledMeeting } from '../lib/storage.js';
import { formatMeetingId } from '../lib/format.js';

export function MeetingsTab({
  meetings,
  recents,
  pmi,
  search,
  onStart,
  onCopy,
  onDelete,
  onRejoin,
  onSchedule,
  onStartPmi,
  onCopyPmi,
}: {
  meetings: ScheduledMeeting[];
  recents: RecentMeeting[];
  pmi: string;
  search: string;
  onStart: (meeting: ScheduledMeeting) => void;
  onCopy: (meeting: ScheduledMeeting) => void;
  onDelete: (id: string) => void;
  onRejoin: (recent: RecentMeeting) => void;
  onSchedule: () => void;
  onStartPmi: () => void;
  onCopyPmi: () => void;
}) {
  const query = search.trim().toLowerCase();
  const match = (title: string, room: string) =>
    !query || title.toLowerCase().includes(query) || room.includes(query.replace(/\D/g, ''));
  const filteredMeetings = meetings.filter((m) => match(m.title || '', m.room));
  const filteredRecents = recents.filter((r) => match(r.title || '', r.room));

  return (
    <div className="tab-pane is-active">
      <div className="pane-head">
        <div>
          <h1>Meetings</h1>
          <p className="pane-sub">Schedule, start and rejoin — all in one place.</p>
        </div>
        <Btn kind="primary" onClick={onSchedule}>
          <Icon name="i-calendar" size="sm" /> Schedule a meeting
        </Btn>
      </div>

      <div className="zcard pmi-card">
        <div className="zcard-head">
          <h3>Personal meeting room</h3>
          <span className="zpill">Always open</span>
        </div>
        <div className="pmi-row">
          <div className="pmi-id">
            <code>{formatMeetingId(pmi)}</code>
          </div>
          <Btn onClick={onCopyPmi}>
            <Icon name="i-copy" size="sm" /> Copy invite
          </Btn>
          <Btn kind="primary" onClick={onStartPmi}>
            <Icon name="i-video" size="sm" /> Start
          </Btn>
        </div>
      </div>

      <div className="zcard">
        <div className="zcard-head">
          <h3>Upcoming</h3>
          <span className="zcount">{meetings.length ? `${meetings.length} meeting${meetings.length === 1 ? '' : 's'}` : ''}</span>
        </div>
        <ul className="meeting-list tall">
          {filteredMeetings.length === 0 ? (
            <Empty
              title={query ? `No match for “${search}”` : 'No meetings yet'}
              hint={query ? 'Try another title or meeting ID.' : 'Hit “Schedule a meeting” and it shows up here.'}
            />
          ) : (
            filteredMeetings.map((meeting) => (
              <ScheduledRow
                key={meeting.id}
                meeting={meeting}
                onStart={() => onStart(meeting)}
                onCopy={() => onCopy(meeting)}
                onDelete={() => onDelete(meeting.id)}
              />
            ))
          )}
        </ul>
      </div>

      <div className="zcard">
        <div className="zcard-head">
          <h3>Recent</h3>
        </div>
        <ul className="meeting-list tall">
          {filteredRecents.length === 0 ? (
            <Empty title="No recent meetings" hint="Meetings you start or join appear here." />
          ) : (
            filteredRecents.map((recent) => (
              <RecentRow key={`${recent.room}-${recent.ts}`} recent={recent} onJoin={() => onRejoin(recent)} />
            ))
          )}
        </ul>
      </div>
    </div>
  );
}

export function RecordingsTab({
  recordings,
  onRemove,
}: {
  recordings: RecordingEntry[];
  onRemove: (index: number) => void;
}) {
  return (
    <div className="tab-pane is-active">
      <div className="pane-head">
        <div>
          <h1>Recordings</h1>
          <p className="pane-sub">Local recordings saved to your device — never uploaded.</p>
        </div>
      </div>
      <div className="zcard">
        <div className="zcard-head">
          <h3>Local recordings</h3>
          <span className="zcount">{recordings.length ? `${recordings.length} file${recordings.length === 1 ? '' : 's'}` : ''}</span>
        </div>
        <ul className="meeting-list tall">
          {recordings.length === 0 ? (
            <Empty
              title="No recordings yet"
              hint="In a meeting open More → Record locally. Files download straight to this device."
            />
          ) : (
            recordings.map((entry, index) => (
              <RecordingRow key={`${entry.ts}-${index}`} entry={entry} onRemove={() => onRemove(index)} />
            ))
          )}
        </ul>
      </div>
    </div>
  );
}

export function MoreTab({
  config,
  onSettings,
  onJoin,
  onSchedule,
  onSelfTest,
}: {
  config: { privacy: { publicStun: boolean; turn: boolean }; maxParticipants: number } | null;
  onSettings: () => void;
  onJoin: () => void;
  onSchedule: () => void;
  onSelfTest: () => void;
}) {
  return (
    <div className="tab-pane is-active">
      <div className="pane-head">
        <div>
          <h1>More</h1>
          <p className="pane-sub">Settings, shortcuts and privacy details.</p>
        </div>
      </div>
      <div className="more-grid">
        <button className="more-card" onClick={onSettings}>
          <Icon name="i-gear" />
          <b>Audio &amp; video settings</b>
          <small>Pick camera, microphone and speaker</small>
        </button>
        <button className="more-card" onClick={onJoin}>
          <Icon name="i-plus" />
          <b>Join with meeting ID</b>
          <small>Enter an ID to join instantly</small>
        </button>
        <button className="more-card" onClick={onSchedule}>
          <Icon name="i-calendar" />
          <b>Schedule</b>
          <small>Plan a meeting for later</small>
        </button>
        <button className="more-card" onClick={onSelfTest}>
          <Icon name="i-shield" />
          <b>Test my setup</b>
          <small>Camera, mic, E2EE, signaling and ICE — one click, all local</small>
        </button>
        <div className="more-card static">
          <Icon name="i-info" />
          <b>Keyboard shortcuts</b>
          <small>A mute · V video · C chat · P participants · H hand · Esc close</small>
        </div>
      </div>

      <div className="zcard about-card">
        <h3>Privacy &amp; encryption</h3>
        <ul className="privacy-list">
          <li>
            <Icon name="i-lock" size="sm" /> <b>End-to-end encrypted media</b> — WebRTC insertable streams with a
            256-bit key that only exists in the invite link fragment. The server never receives it.
          </li>
          <li>
            <Icon name="i-lock" size="sm" /> <b>Encrypted chat</b> — messages are AES-GCM sealed in your browser; the
            server only relays ciphertext.
          </li>
          <li>
            <Icon name="i-shield" size="sm" /> <b>Ephemeral rooms</b> — no database, no message history on the server,
            no access logs, rooms are wiped when empty.
          </li>
          <li>
            <Icon name="i-users" size="sm" /> <b>Peer-to-peer</b> — audio/video never pass through the server. Up to{' '}
            {config?.maxParticipants ?? 24} participants per room.
          </li>
          <li>
            <Icon name="i-search" size="sm" />{' '}
            {config?.privacy.publicStun
              ? 'Public STUN is enabled for connectivity (a third party can see your IP — like any WebRTC app). Enable privacy mode in Settings to disable it.'
              : 'Privacy mode: no third-party STUN servers are contacted.'}
            {config?.privacy.turn ? ' A self-hosted TURN relay is configured.' : ''}
          </li>
        </ul>
      </div>
    </div>
  );
}
