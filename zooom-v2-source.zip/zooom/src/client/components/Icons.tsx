/** Inline SVG sprite — no icon font, no CDN, nothing external to leak. */
export function Sprite() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" style={{ display: 'none' }} aria-hidden="true">
      <symbol id="i-mic" viewBox="0 0 24 24"><rect x="9" y="2.5" width="6" height="11" rx="3" /><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18.2V21M8.6 21h6.8" /></symbol>
      <symbol id="i-mic-off" viewBox="0 0 24 24"><path d="M15 10.5V5.5a3 3 0 0 0-5.9-.7M9 9.3v3.2a3 3 0 0 0 4.2 2.8" /><path d="M5.5 11.5a6.5 6.5 0 0 0 10 5.8M12 18.2V21M8.6 21h6.8M3 3l18 18" /></symbol>
      <symbol id="i-video" viewBox="0 0 24 24"><rect x="2.5" y="6" width="13" height="12" rx="3" /><path d="M15.5 12.4l4.3-2.6a1 1 0 0 1 1.7.9v6.6a1 1 0 0 1-1.7.9l-4.3-2.6v-3.2Z" /></symbol>
      <symbol id="i-video-off" viewBox="0 0 24 24"><path d="M12 6h.5a3 3 0 0 1 3 3v.5M15.5 12.4l4.3-2.6a1 1 0 0 1 1.7.9v6.6a1 1 0 0 1-.6.8M15.5 15.2v.3a3 3 0 0 1-3 3h-7a3 3 0 0 1-3-3V9a3 3 0 0 1 1.2-2.4" /><path d="M3 3l18 18" /></symbol>
      <symbol id="i-users" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.4" /><path d="M2.8 20v-1.2A4.8 4.8 0 0 1 7.6 14h2.8a4.8 4.8 0 0 1 4.8 4.8V20" /><path d="M17 5.2a3.4 3.4 0 0 1 0 6.6M18.4 14.2A4.8 4.8 0 0 1 21.5 18.8V20" /></symbol>
      <symbol id="i-chat" viewBox="0 0 24 24"><path d="M20.5 11.6c0 4.2-3.8 7.6-8.5 7.6-1 0-2-.2-2.9-.5L4.5 20.5l1.3-3.6a7.2 7.2 0 0 1-1.8-4.7C4 8 7.8 4.5 12.5 4.5s8 3.5 8 7.1Z" /></symbol>
      <symbol id="i-share" viewBox="0 0 24 24"><rect x="2.4" y="4.4" width="19.2" height="12.6" rx="2.4" /><path d="M8.4 21h7.2M12 17v4M12 13.2V7.6M9.2 10.4 12 7.6l2.8 2.8" /></symbol>
      <symbol id="i-share-off" viewBox="0 0 24 24"><rect x="2.4" y="4.4" width="19.2" height="12.6" rx="2.4" /><path d="M8.4 21h7.2M12 17v4M3 3l18 18" /></symbol>
      <symbol id="i-smile" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" /><path d="M8.4 14.2a4.4 4.4 0 0 0 7.2 0" /><circle cx="9" cy="9.6" r=".9" fill="currentColor" stroke="none" /><circle cx="15" cy="9.6" r=".9" fill="currentColor" stroke="none" /></symbol>
      <symbol id="i-more" viewBox="0 0 24 24"><circle cx="5.5" cy="12" r="1.7" fill="currentColor" stroke="none" /><circle cx="12" cy="12" r="1.7" fill="currentColor" stroke="none" /><circle cx="18.5" cy="12" r="1.7" fill="currentColor" stroke="none" /></symbol>
      <symbol id="i-record" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.6" /><circle cx="12" cy="12" r="4" fill="currentColor" stroke="none" /></symbol>
      <symbol id="i-gear" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.1" /><path d="M19.2 15.1a1.7 1.7 0 0 0 .35 1.86l.05.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1.03 1.56V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.56 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.56-1.03H3a2 2 0 1 1 0-4h.1A1.7 1.7 0 0 0 4.66 8.9a1.7 1.7 0 0 0-.34-1.87l-.06-.06A2 2 0 1 1 7.09 4.14l.06.06a1.7 1.7 0 0 0 1.87.34H9.1A1.7 1.7 0 0 0 10.13 3V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1.03 1.56 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87v.06a1.7 1.7 0 0 0 1.56 1.03H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.7 1Z" /></symbol>
      <symbol id="i-copy" viewBox="0 0 24 24"><rect x="9" y="9" width="11.5" height="11.5" rx="2.4" /><path d="M6.5 15h-.9a2.2 2.2 0 0 1-2.2-2.2V5.2A2.2 2.2 0 0 1 5.6 3h7.6a2.2 2.2 0 0 1 2.2 2.2v.9" /></symbol>
      <symbol id="i-plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" /></symbol>
      <symbol id="i-calendar" viewBox="0 0 24 24"><rect x="3.2" y="5" width="17.6" height="16" rx="2.6" /><path d="M8 3v4M16 3v4M3.2 10h17.6" /></symbol>
      <symbol id="i-link" viewBox="0 0 24 24"><path d="M10.4 13.6a4.4 4.4 0 0 0 6.2 0l2.5-2.5a4.4 4.4 0 0 0-6.2-6.2l-1.4 1.4" /><path d="M13.6 10.4a4.4 4.4 0 0 0-6.2 0l-2.5 2.5a4.4 4.4 0 0 0 6.2 6.2l1.4-1.4" /></symbol>
      <symbol id="i-arrow-left" viewBox="0 0 24 24"><path d="M19 12H5M11 6l-6 6 6 6" /></symbol>
      <symbol id="i-chev-left" viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></symbol>
      <symbol id="i-chev-right" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7" /></symbol>
      <symbol id="i-chev-down" viewBox="0 0 24 24"><path d="M6 9.5l6 6 6-6" /></symbol>
      <symbol id="i-close" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18" /></symbol>
      <symbol id="i-send" viewBox="0 0 24 24"><path d="M21.4 2.6 2.2 10.1l7.3 3.4L21.4 2.6ZM21.4 2.6 13.7 22.4l-3.5-7.4" /></symbol>
      <symbol id="i-hand" viewBox="0 0 24 24"><path d="M8.2 12.2V5.6a1.7 1.7 0 0 1 3.4 0V11m0 0V4.4a1.7 1.7 0 0 1 3.4 0V11m0 0V6.8a1.7 1.7 0 0 1 3.4 0V14a7 7 0 0 1-7 7h-1a6 6 0 0 1-6-6v-3a1.7 1.7 0 0 1 3.4 0" /></symbol>
      <symbol id="i-pin" viewBox="0 0 24 24"><path d="M12 16.5V21M8.6 3h6.8l-.9 5.8 3.3 3.3H6.2l3.3-3.3L8.6 3Z" /></symbol>
      <symbol id="i-expand" viewBox="0 0 24 24"><path d="M9 3.5H3.5V9M15 3.5h5.5V9M15 20.5h5.5V15M9 20.5H3.5V15" /></symbol>
      <symbol id="i-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.8" /><path d="M12 7.4V12l3.1 2" /></symbol>
      <symbol id="i-shield" viewBox="0 0 24 24"><path d="M12 3l7.4 3v6c0 4.9-3.1 7.9-7.4 9-4.3-1.1-7.4-4.1-7.4-9V6L12 3Z" /><path d="M9 12l2 2 4-4" /></symbol>
      <symbol id="i-lock" viewBox="0 0 24 24"><rect x="4.5" y="10.5" width="15" height="10.5" rx="2.4" /><path d="M8 10.5V7.8a4 4 0 0 1 8 0v2.7M12 15v2" /></symbol>
      <symbol id="i-info" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.8" /><path d="M12 11v5.4" /><circle cx="12" cy="7.9" r="1" fill="currentColor" stroke="none" /></symbol>
      <symbol id="i-call-end" viewBox="0 0 24 24"><path d="M2.6 9.6c5-4 13.8-4 18.8 0v3a2 2 0 0 1-2.4 2l-2.5-.7a2 2 0 0 1-1.4-1.6l-.2-1.5a8.9 8.9 0 0 0-4.8 0l-.2 1.5a2 2 0 0 1-1.4 1.6l-2.5.7a2 2 0 0 1-2.4-2v-3Z" /></symbol>
      <symbol id="i-search" viewBox="0 0 24 24"><circle cx="10.8" cy="10.8" r="6.8" /><path d="M15.8 15.8 21 21" /></symbol>
      <symbol id="i-bell" viewBox="0 0 24 24"><path d="M18 9.2a6 6 0 1 0-12 0c0 5.2-2 6.6-2 6.6h16s-2-1.4-2-6.6ZM13.7 20a2 2 0 0 1-3.4 0" /></symbol>
      <symbol id="i-home" viewBox="0 0 24 24"><path d="M4 10.5 12 3.5l8 7v8.3a1.7 1.7 0 0 1-1.7 1.7H5.7A1.7 1.7 0 0 1 4 18.8v-8.3Z" /><path d="M9.5 20.5v-6.8h5v6.8" /></symbol>
      <symbol id="i-apps" viewBox="0 0 24 24"><rect x="3.5" y="3.5" width="7" height="7" rx="2" /><rect x="13.5" y="3.5" width="7" height="7" rx="2" /><rect x="3.5" y="13.5" width="7" height="7" rx="2" /><rect x="13.5" y="13.5" width="7" height="7" rx="2" /></symbol>
      <symbol id="i-doc" viewBox="0 0 24 24"><path d="M6 3.5h7.5L19 9v11.5H6z" /><path d="M13.5 3.5V9H19" /></symbol>
      <symbol id="i-video2" viewBox="0 0 24 24"><rect x="3" y="6.5" width="12.5" height="11" rx="2.6" /><path d="M15.5 12.4l4.2-2.4a.9.9 0 0 1 1.3.8v6.4a.9.9 0 0 1-1.3.8l-4.2-2.4" /></symbol>
      <symbol id="g-camera" viewBox="0 0 48 48"><rect x="7" y="15" width="24" height="18" rx="5.5" fill="#fff" /><path d="M33.5 22.2l5.9-3.4a2 2 0 0 1 3 1.7v10.9a2 2 0 0 1-3 1.7l-5.9-3.4V22.2Z" fill="#fff" /></symbol>
      <symbol id="g-plus" viewBox="0 0 48 48"><path d="M24 10.5v27M10.5 24h27" stroke="#fff" strokeWidth="5.4" strokeLinecap="round" /></symbol>
      <symbol id="g-calendar31" viewBox="0 0 48 48"><rect x="8" y="10" width="32" height="29" rx="6" fill="#fff" /><path d="M16 6.5v6M32 6.5v6" stroke="#fff" strokeWidth="3.6" strokeLinecap="round" /><rect x="8" y="17.5" width="32" height="2.4" fill="#0e71eb" opacity=".35" /><text x="24" y="34.5" textAnchor="middle" fontFamily="Inter, Segoe UI, Arial, sans-serif" fontSize="15" fontWeight="800" fill="#0e71eb">31</text></symbol>
      <symbol id="g-share" viewBox="0 0 48 48"><rect x="7" y="7" width="34" height="34" rx="10" fill="#fff" /><path d="M24 34.5V17.5M17.6 23.6 24 17.2l6.4 6.4" stroke="#0e71eb" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" /></symbol>
      <symbol id="g-room" viewBox="0 0 24 24"><path d="M4 10.2 12 3.8l8 6.4v8a1.6 1.6 0 0 1-1.6 1.6H5.6A1.6 1.6 0 0 1 4 18.2v-8Z" /></symbol>
    </svg>
  );
}

export function Icon({ name, size = 'md' }: { name: string; size?: 'xs' | 'sm' | 'md' }) {
  const cls = size === 'xs' ? 'ic xs' : size === 'sm' ? 'ic sm' : 'ic';
  return (
    <svg className={cls} aria-hidden="true">
      <use href={`#${name}`} />
    </svg>
  );
}

export const FLAG = { name: 'g-room' } as const;
