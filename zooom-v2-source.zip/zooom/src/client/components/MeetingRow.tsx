import { Icon } from './Icons.js';
import type { RecentMeeting, RecordingEntry, ScheduledMeeting } from '../lib/storage.js';
import { formatMeetingId } from '../lib/format.js';

export function ScheduledRow({
  meeting,
  onStart,
  onCopy,
  onDelete,
}: {
  meeting: ScheduledMeeting;
  onStart: () => void;
  onCopy: () => void;
  onDelete?: () => void;
}) {
  const when = new Date(meeting.when);
  return (
    <li className="meeting-item">
      <span className="mi-ic">
        <Icon name="i-calendar" size="sm" />
      </span>
      <span className="mi-body">
        <span className="mi-title">{meeting.title || 'Meeting'}</span>
        <span className="mi-sub">
          {when.toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' })} · ID{' '}
          {formatMeetingId(meeting.room)}
        </span>
      </span>
      <span className="mi-actions">
        <button className="chip-btn" onClick={onStart}>
          Start
        </button>
        <button className="chip-btn ghost" onClick={onCopy}>
          Copy link
        </button>
        {onDelete ? (
          <button className="chip-btn ghost" onClick={onDelete}>
            Delete
          </button>
        ) : null}
      </span>
    </li>
  );
}

export function RecentRow({ recent, onJoin }: { recent: RecentMeeting; onJoin: () => void }) {
  return (
    <li className="meeting-item">
      <span className="mi-ic">
        <Icon name="i-clock" size="sm" />
      </span>
      <span className="mi-body">
        <span className="mi-title">{recent.title}</span>
        <span className="mi-sub">
          ID {formatMeetingId(recent.room)} · {new Date(recent.ts).toLocaleDateString()}
        </span>
      </span>
      <span className="mi-actions">
        <button className="chip-btn" onClick={onJoin}>
          Rejoin
        </button>
      </span>
    </li>
  );
}

export function RecordingRow({ entry, onRemove }: { entry: RecordingEntry; onRemove: () => void }) {
  return (
    <li className="meeting-item">
      <span className="mi-ic">
        <Icon name="i-record" size="sm" />
      </span>
      <span className="mi-body">
        <span className="mi-title">{entry.name}</span>
        <span className="mi-sub">
          {new Date(entry.ts).toLocaleString()} · {entry.size}
        </span>
      </span>
      <span className="mi-actions">
        <button className="chip-btn ghost" onClick={onRemove}>
          Remove
        </button>
      </span>
    </li>
  );
}
