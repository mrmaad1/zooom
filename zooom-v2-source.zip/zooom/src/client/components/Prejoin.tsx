import { useEffect, useRef, useState } from 'react';
import { Icon } from './Icons.js';
import { Btn } from './ui.js';
import { formatMeetingId, initials } from '../lib/format.js';
import type { MediaState } from '../lib/media.js';

export function Prejoin({
  room,
  mode,
  name,
  mediaState,
  stream,
  e2eeSupported,
  needsKey,
  onNameChange,
  onToggleMic,
  onToggleCam,
  onSettings,
  onJoin,
  onUnlock,
  onHome,
  error,
}: {
  room: string | null;
  mode: 'new' | 'join' | 'pmi';
  name: string;
  mediaState: MediaState;
  stream: MediaStream | null;
  e2eeSupported: boolean;
  needsKey: boolean;
  onNameChange: (name: string) => void;
  onToggleMic: () => void;
  onToggleCam: () => void;
  onSettings: () => void;
  onJoin: (roomId: string, name: string) => void;
  onUnlock: (input: string) => void;
  onHome: () => void;
  error: string | null;
}) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [roomInput, setRoomInput] = useState(room ?? '');
  const [keyInput, setKeyInput] = useState('');
  const isNew = mode !== 'join';
  const camOn = mediaState.camOn && !!mediaState.hasCam;

  useEffect(() => {
    if (videoRef.current && stream) videoRef.current.srcObject = stream;
  }, [stream]);

  return (
    <section className="screen is-active" style={{ background: '#151515' }}>
      <div className="pj-topbar">
        <div className="wbrand">
          <span className="wlogo small">
            <svg viewBox="0 0 40 40" aria-hidden="true">
              <rect width="40" height="40" rx="9" fill="#2D8CFF" />
              <path d="M11 16a3 3 0 0 1 3-3h6a3 3 0 0 1 3 3v9a3 3 0 0 1-3 3h-6a3 3 0 0 1-3-3v-9Z" fill="#fff" />
              <path d="M24.6 19.6l3.9-2.4c.7-.4 1.5.1 1.5.9v7.8c0 .8-.8 1.3-1.5.9l-3.9-2.4v-4.8Z" fill="#fff" />
            </svg>
          </span>
          <span className="wbrand-text">
            <b className="light">zooom</b>
          </span>
        </div>
        <div className="pj-topright">
          <span className={e2eeSupported ? 'e2ee-chip' : 'e2ee-chip warn'}>
            <Icon name="i-lock" size="xs" /> {e2eeSupported ? 'End-to-end encrypted' : 'Transit encrypted'}
          </span>
          <button className="ghost-ic" onClick={onSettings} title="Settings">
            <Icon name="i-gear" />
          </button>
        </div>
      </div>

      <div className="pj-wrap">
        <div className="pj-preview">
          <div className={`preview-stage ${camOn ? 'cam-on' : ''}`}>
            <video ref={videoRef} autoPlay muted playsInline />
            <div className="preview-avatar">{initials(name)}</div>
            {!camOn ? (
              <div className="preview-badge">{mediaState.hasCam ? 'Camera is off' : 'No camera detected'}</div>
            ) : null}
            <div className="preview-name">{name || 'Your name'}</div>
            <div className="preview-mics">
              <button className={`pj-ctrl ${mediaState.micOn ? '' : 'off'}`} onClick={onToggleMic} title="Mute / unmute">
                <Icon name={mediaState.micOn ? 'i-mic' : 'i-mic-off'} />
              </button>
              <button className={`pj-ctrl ${camOn ? '' : 'off'}`} onClick={onToggleCam} title="Start / stop video">
                <Icon name={camOn ? 'i-video' : 'i-video-off'} />
              </button>
              <button className="pj-ctrl" onClick={onSettings} title="Audio & video settings">
                <Icon name="i-gear" />
              </button>
            </div>
          </div>
          <div className="preview-hint">
            {mediaState.hasMic || mediaState.hasCam
              ? 'Your media is captured locally and goes straight to other participants — nothing is stored on a server.'
              : 'Camera & microphone unavailable — you can still join and see everyone. Check browser permissions to turn them on.'}
          </div>
        </div>

        <div className="pj-panel">
          <h2>{isNew ? 'Start Meeting' : 'Join Meeting'}</h2>
          {isNew ? (
            <p className="pj-room-line">
              Meeting ID <b>{formatMeetingId(room ?? '')}</b>
            </p>
          ) : null}

          {!isNew ? (
            <label className="zfield">
              <span>Meeting ID</span>
              <input
                value={roomInput}
                inputMode="numeric"
                onChange={(e) => setRoomInput(e.target.value)}
                placeholder="Enter meeting ID"
              />
            </label>
          ) : null}

          <label className="zfield">
            <span>Your name</span>
            <input value={name} maxLength={42} onChange={(e) => onNameChange(e.target.value)} placeholder="Enter your name" />
          </label>

          {needsKey ? (
            <div className="zfield">
              <span>Meeting key (this room is end-to-end encrypted)</span>
              <div className="key-row">
                <input
                  value={keyInput}
                  onChange={(e) => setKeyInput(e.target.value)}
                  placeholder="Paste the invite link"
                  className="mono"
                />
                <Btn kind="primary" onClick={() => onUnlock(keyInput)}>
                  Unlock
                </Btn>
              </div>
              <p className="hint">Without the key nobody — including the server — can decrypt the media.</p>
            </div>
          ) : null}

          <label className="switch-row">
            <input type="checkbox" checked={!mediaState.micOn} onChange={onToggleMic} />
            <span className="switch-ui" />
            <span className="switch-label">Don't connect to audio</span>
          </label>
          <label className="switch-row">
            <input type="checkbox" checked={!camOn} onChange={onToggleCam} />
            <span className="switch-ui" />
            <span className="switch-label">Turn off my video</span>
          </label>

          <Btn
            kind="primary"
            className="lg"
            onClick={() => onJoin(roomInput, name)}
            disabled={needsKey}
          >
            {isNew ? 'Start' : 'Join'}
          </Btn>
          {error ? <p className="pj-err">{error}</p> : null}
          <Btn kind="link" onClick={onHome}>
            <Icon name="i-arrow-left" size="sm" /> Back to home
          </Btn>

          <div className="pj-footer">
            <Icon name="i-lock" size="xs" />
            <span>No downloads · no 40-minute cap · free forever.</span>
          </div>
        </div>
      </div>
    </section>
  );
}
