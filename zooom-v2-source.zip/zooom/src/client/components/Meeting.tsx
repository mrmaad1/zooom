import { useEffect, useMemo, useRef, useState } from 'react';
import { Icon } from './Icons.js';
import { formatMeetingId, initials, clockTime, duration } from '../lib/format.js';
import type { CallParticipant, CallSnapshot, ChatItem } from '../lib/call.js';
import type { MediaState } from '../lib/media.js';

const EMOJIS = ['👍', '👏', '❤️', '😂', '😮', '🎉', '🙏', '🔥', '😢', '👌', '💯', '🐼'];

function Tile({
  participant,
  stream,
  focus,
  onPin,
}: {
  participant: CallParticipant;
  stream: MediaStream | null;
  focus: boolean;
  onPin: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const hasVideo = participant.videoOn || participant.sharing;

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    if (el.srcObject !== stream) el.srcObject = stream ?? null;
    if (stream && hasVideo) void el.play().catch(() => undefined);
  }, [stream, hasVideo]);

  return (
    <div
      className={[
        'tile',
        hasVideo ? 'has-video' : '',
        participant.self && !participant.sharing ? 'mirror' : '',
        participant.sharing ? 'sharing' : '',
        focus ? 'is-focus' : '',
      ]
        .filter(Boolean)
        .join(' ')}
      onDoubleClick={onPin}
      id={`tile-${participant.id}`}
    >
      <video ref={videoRef} autoPlay playsInline muted={participant.self} />
      <div className="tile-avatar">{initials(participant.name)}</div>
      <div className="tile-badges">
        {participant.isHost ? <span className="tile-badge host">Host</span> : null}
        {participant.sharing ? <span className="tile-badge share">Presenting</span> : null}
        {participant.hand ? <span className="tile-badge hand">✋ Hand raised</span> : null}
      </div>
      <div className="tile-label">
        {participant.muted ? <Icon name="i-mic-off" size="xs" /> : null}
        <span className="name">{participant.name}</span>
        {participant.self ? <span className="you">(You)</span> : null}
      </div>
      <div className="tile-actions">
        <button title="Pin to speaker view" onClick={onPin}>
          <Icon name="i-pin" />
        </button>
      </div>
    </div>
  );
}

export function MeetingScreen({
  snapshot,
  room,
  chat,
  mediaState,
  localStream,
  isHost,
  recording,
  recElapsed,
  e2eeSupported,
  onToggleMic,
  onToggleCam,
  onShareToggle,
  onHand,
  onLeave,
  onChat,
  onReaction,
  onCopyInvite,
  onInfo,
  onSettings,
  onRecord,
  onRename,
  onMuteAll,
  onAskMute,
  floats,
}: {
  snapshot: CallSnapshot;
  room: string;
  chat: ChatItem[];
  mediaState: MediaState;
  localStream: MediaStream | null;
  isHost: boolean;
  recording: boolean;
  recElapsed: string;
  e2eeSupported: boolean;
  onToggleMic: () => void;
  onToggleCam: () => void;
  onShareToggle: () => void;
  onHand: () => void;
  onLeave: () => void;
  onChat: (text: string, to: string) => void;
  onReaction: (emoji: string) => void;
  onCopyInvite: () => void;
  onInfo: () => void;
  onSettings: () => void;
  onRecord: () => void;
  onRename: () => void;
  onMuteAll: () => void;
  onAskMute: (id: string, name: string) => void;
  floats: { id: number; emoji: string; left: number }[];
}) {
  const [panel, setPanel] = useState<'people' | 'chat' | null>(null);
  const [unread, setUnread] = useState(0);
  const [view, setView] = useState<'gallery' | 'speaker'>('gallery');
  const [pinned, setPinned] = useState<string | null>(null);
  const [reactOpen, setReactOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [chatTo, setChatTo] = useState('everyone');
  const [chatText, setChatText] = useState('');
  const chatEndRef = useRef<HTMLDivElement | null>(null);
  const chatCount = useRef(0);

  const self = snapshot.participants.find((p) => p.self);
  const others = snapshot.participants.filter((p) => !p.self);
  const total = snapshot.participants.length;

  /* unread badge */
  useEffect(() => {
    if (chat.length > chatCount.current) {
      if (panel !== 'chat') {
        const incoming = chat.slice(chatCount.current).filter((m) => !m.system && !m.mine);
        if (incoming.length > 0) setUnread((n) => n + incoming.length);
      }
      chatCount.current = chat.length;
    }
    if (panel === 'chat') {
      setUnread(0);
      chatEndRef.current?.scrollIntoView({ block: 'end' });
    }
  }, [chat, panel]);

  /* keyboard shortcuts */
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement | null)?.tagName?.toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
      if (event.metaKey || event.ctrlKey || event.altKey) return;
      switch (event.key.toLowerCase()) {
        case 'a':
          onToggleMic();
          break;
        case 'v':
          onToggleCam();
          break;
        case 'h':
          onHand();
          break;
        case 'c':
          setPanel((p) => (p === 'chat' ? null : 'chat'));
          break;
        case 'p':
          setPanel((p) => (p === 'people' ? null : 'people'));
          break;
        default:
          break;
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onToggleMic, onToggleCam, onHand]);

  const focusId = useMemo(() => {
    if (pinned && snapshot.participants.some((p) => p.id === pinned)) return pinned;
    const sharing = snapshot.participants.find((p) => p.sharing);
    return sharing?.id ?? snapshot.participants[0]?.id ?? null;
  }, [pinned, snapshot.participants]);

  const columns = (() => {
    if (total <= 1) return 1;
    if (total === 2) return 2;
    if (total === 3) return 3;
    if (total === 4) return 2;
    if (total <= 9) return 3;
    if (total <= 12) return 4;
    return 5;
  })();

  const streamFor = (participant: CallParticipant): MediaStream | null => {
    if (participant.self) return localStream;
    return snapshot.streams[participant.id] ?? null;
  };

  const sendChat = () => {
    if (!chatText.trim()) return;
    onChat(chatText, chatTo);
    setChatText('');
  };

  const reactEmoji = (emoji: string) => {
    onReaction(emoji);
    setReactOpen(false);
  };

  return (
    <section className="screen meeting is-active">
      <div className="meeting-main">
        <div className="stage">
          <div className="stage-top">
            <div className="stage-top-left">
              <span className="m-room-name">Zooom Meeting</span>
              <span className="m-room-id">Meeting ID: {formatMeetingId(room)}</span>
              {e2eeSupported ? (
                <span className="e2ee-chip" title="Media is end-to-end encrypted with the meeting key">
                  <Icon name="i-lock" size="xs" /> E2EE
                </span>
              ) : (
                <span className="e2ee-chip warn" title="This browser cannot do insertable-streams encryption">
                  <Icon name="i-lock" size="xs" /> Transit only
                </span>
              )}
            </div>
            <div className="stage-top-right">
              <div className="vswitch">
                <button
                  className={view === 'gallery' ? 'is-active' : ''}
                  onClick={() => {
                    setView('gallery');
                    setPinned(null);
                  }}
                >
                  <Icon name="i-apps" size="sm" /> Gallery
                </button>
                <button className={view === 'speaker' ? 'is-active' : ''} onClick={() => setView('speaker')}>
                  <Icon name="i-video2" size="sm" /> Speaker
                </button>
              </div>
              <button className="m-top-btn" onClick={onCopyInvite}>
                <Icon name="i-link" size="sm" /> Invite
              </button>
            </div>
          </div>

          <div
            className="video-grid"
            id="video-grid"
            data-cols={view === 'speaker' ? undefined : String(columns)}
            data-mode={view}
          >
            {view === 'speaker' && focusId ? (
              <>
                {snapshot.participants
                  .filter((p) => p.id === focusId)
                  .map((p) => (
                    <Tile
                      key={p.id}
                      participant={p}
                      stream={streamFor(p)}
                      focus
                      onPin={() => setPinned((cur) => (cur === p.id ? null : p.id))}
                    />
                  ))}
                {snapshot.participants
                  .filter((p) => p.id !== focusId)
                  .map((p) => (
                    <Tile
                      key={p.id}
                      participant={p}
                      stream={streamFor(p)}
                      focus={false}
                      onPin={() => {
                        setPinned(p.id);
                        setView('speaker');
                      }}
                    />
                  ))}
              </>
            ) : (
              snapshot.participants.map((p) => (
                <Tile
                  key={p.id}
                  participant={p}
                  stream={streamFor(p)}
                  focus={false}
                  onPin={() => {
                    setPinned(p.id);
                    setView('speaker');
                  }}
                />
              ))
            )}
          </div>

          <div className="reaction-layer" aria-live="polite">
            {floats.map((f) => (
              <div key={f.id} className="float-emoji" style={{ left: `${f.left}%` }}>
                {f.emoji}
              </div>
            ))}
          </div>

          {recording ? (
            <div className="rec-badge">
              <i /> Recording {recElapsed}
            </div>
          ) : null}
          {snapshot.status === 'error' ? <div className="net-badge">Reconnecting…</div> : null}
        </div>

        {panel ? (
          <aside className="side-panel">
            <div className="panel-head">
              <div className="panel-tabs">
                <button className={panel === 'people' ? 'is-active' : ''} onClick={() => setPanel('people')}>
                  Participants <span className="count">{total}</span>
                </button>
                <button className={panel === 'chat' ? 'is-active' : ''} onClick={() => setPanel('chat')}>
                  Chat {unread > 0 ? <span className="count dot">{unread}</span> : null}
                </button>
              </div>
              <button className="ghost-ic dark" onClick={() => setPanel(null)} title="Close">
                <Icon name="i-close" />
              </button>
            </div>

            {panel === 'people' ? (
              <div className="panel-body">
                <div className="panel-sub">
                  <span>
                    {total} participant{total === 1 ? '' : 's'}
                  </span>
                  {isHost ? (
                    <button className="zmini" onClick={onMuteAll}>
                      Mute all
                    </button>
                  ) : null}
                </div>
                <ul className="people-list">
                  {snapshot.participants.map((p) => (
                    <li className="person" key={p.id}>
                      <span className="p-av">{initials(p.name)}</span>
                      <span className="p-name">
                        {p.name}
                        {p.self ? ' (You)' : ''}
                      </span>
                      <span className="p-tags">
                        {p.isHost ? <span className="host-tag">Host</span> : null}
                        {p.hand ? <Icon name="i-hand" size="xs" /> : null}
                        <Icon name={p.muted ? 'i-mic-off' : 'i-mic'} size="xs" />
                        {!p.videoOn ? <Icon name="i-video-off" size="xs" /> : null}
                      </span>
                      {!p.self && isHost ? (
                        <button className="p-more" title="More" onClick={() => onAskMute(p.id, p.name)}>
                          <Icon name="i-more" size="xs" />
                        </button>
                      ) : null}
                    </li>
                  ))}
                </ul>
                <div className="panel-note">
                  <Icon name="i-info" size="xs" />
                  <span>
                    {isHost
                      ? 'You are the host. Chat and media are end-to-end encrypted — the server only relays ciphertext.'
                      : 'The host can mute participants. Everyone can chat, share and react.'}
                  </span>
                </div>
              </div>
            ) : (
              <div className="panel-body">
                <ul className="chat-list">
                  {chat.map((item) => (
                    <li
                      key={item.id}
                      className={[
                        'chat-msg',
                        item.system ? 'sys' : '',
                        item.mine ? 'mine' : '',
                        item.privateTo ? 'private' : '',
                        item.locked ? 'locked' : '',
                      ]
                        .filter(Boolean)
                        .join(' ')}
                    >
                      {item.system ? (
                        <span className="cm-text">{item.text}</span>
                      ) : (
                        <>
                          <span className="cm-head">
                            <span className="cm-name">{item.name ?? 'Guest'}</span>
                            <span className="cm-time">
                              {clockTime(item.ts)}
                              {item.privateTo ? ' · private' : ''}
                            </span>
                          </span>
                          <span className="cm-text">
                            {item.locked ? '🔒 encrypted — key required' : item.text}
                          </span>
                        </>
                      )}
                    </li>
                  ))}
                  <div ref={chatEndRef} />
                </ul>
                <form
                  className="chat-composer"
                  onSubmit={(e) => {
                    e.preventDefault();
                    sendChat();
                  }}
                >
                  <select className="chat-to" value={chatTo} onChange={(e) => setChatTo(e.target.value)} title="Send to">
                    <option value="everyone">To: Everyone</option>
                    {others.map((p) => (
                      <option key={p.id} value={p.id}>
                        To: {p.name}
                      </option>
                    ))}
                  </select>
                  <div className="chat-input-row">
                    <textarea
                      id="chat-input"
                      rows={1}
                      value={chatText}
                      maxLength={4000}
                      placeholder="Type message here…"
                      onChange={(e) => setChatText(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          sendChat();
                        }
                      }}
                    />
                    <button className="send-btn" type="submit" title="Send">
                      <Icon name="i-send" />
                    </button>
                  </div>
                </form>
              </div>
            )}
          </aside>
        ) : null}
      </div>

      <footer className="toolbar">
        <div className="tb-side tb-left">
          <button className="tb-btn" onClick={onInfo} title="Meeting info">
            <Icon name="i-info" />
            <span className="tb-label">Info</span>
          </button>
        </div>

        <div className="tb-center">
          <button className={`tb-btn ${mediaState.micOn ? '' : 'off'}`} onClick={onToggleMic}>
            <Icon name={mediaState.micOn ? 'i-mic' : 'i-mic-off'} />
            <span className="tb-label">{mediaState.micOn ? 'Mute' : 'Unmute'}</span>
          </button>
          <button className={`tb-btn ${mediaState.camOn ? '' : 'off'}`} onClick={onToggleCam}>
            <Icon name={mediaState.camOn ? 'i-video' : 'i-video-off'} />
            <span className="tb-label">{mediaState.camOn ? 'Stop Video' : 'Start Video'}</span>
          </button>
          <button className={`tb-btn ${panel === 'people' ? 'active' : ''}`} onClick={() => setPanel(panel === 'people' ? null : 'people')}>
            <Icon name="i-users" />
            <span className="tb-label">Participants</span>
          </button>
          <button className={`tb-btn ${panel === 'chat' ? 'active' : ''}`} onClick={() => setPanel(panel === 'chat' ? null : 'chat')}>
            <Icon name="i-chat" />
            <span className="tb-label">Chat</span>
            {unread > 0 ? <span className="tb-dot">{Math.min(unread, 99)}</span> : null}
          </button>
          <div style={{ position: 'relative' }}>
            <button className="tb-btn" onClick={() => setReactOpen((v) => !v)}>
              <Icon name="i-smile" />
              <span className="tb-label">React</span>
            </button>
            {reactOpen ? (
              <div className="popover dark" style={{ position: 'absolute', bottom: 66, left: '50%', transform: 'translateX(-50%)', width: 280 }}>
                <div className="pop-title">React</div>
                <div className="emoji-grid">
                  {EMOJIS.map((emoji) => (
                    <button key={emoji} onClick={() => reactEmoji(emoji)}>
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>
            ) : null}
          </div>
          <button className={`tb-btn ${mediaState.sharing ? 'active' : ''}`} onClick={onShareToggle}>
            <Icon name={mediaState.sharing ? 'i-share-off' : 'i-share'} />
            <span className="tb-label">{mediaState.sharing ? 'Stop Share' : 'Share'}</span>
          </button>
          <button className={`tb-btn ${self?.hand ? 'active' : ''}`} onClick={onHand}>
            <Icon name="i-hand" />
            <span className="tb-label">{self?.hand ? 'Lower Hand' : 'Raise Hand'}</span>
          </button>
          <div style={{ position: 'relative' }}>
            <button className={`tb-btn ${recording ? 'rec' : ''}`} onClick={() => setMoreOpen((v) => !v)}>
              <Icon name="i-more" />
              <span className="tb-label">More</span>
            </button>
            {moreOpen ? (
              <div className="popover menu dark" style={{ position: 'absolute', bottom: 66, right: 0, minWidth: 236 }}>
                <button
                  onClick={() => {
                    setMoreOpen(false);
                    onRecord();
                  }}
                >
                  <Icon name="i-record" size="sm" /> {recording ? 'Stop recording' : 'Record locally'}
                </button>
                <button
                  onClick={() => {
                    setMoreOpen(false);
                    void document.documentElement.requestFullscreen?.();
                  }}
                >
                  <Icon name="i-expand" size="sm" /> Full screen
                </button>
                <button
                  onClick={() => {
                    setMoreOpen(false);
                    onSettings();
                  }}
                >
                  <Icon name="i-gear" size="sm" /> Audio &amp; video settings
                </button>
                <button
                  onClick={() => {
                    setMoreOpen(false);
                    onRename();
                  }}
                >
                  <Icon name="i-pin" size="sm" /> Rename myself
                </button>
                <div className="menu-sep" />
                <button
                  className="danger"
                  onClick={() => {
                    setMoreOpen(false);
                    onLeave();
                  }}
                >
                  <Icon name="i-call-end" size="sm" /> Leave meeting
                </button>
              </div>
            ) : null}
          </div>
        </div>

        <div className="tb-side tb-right">
          <button className="tb-btn leave" onClick={onLeave}>
            <Icon name="i-call-end" />
            <span className="tb-label">Leave</span>
          </button>
        </div>
      </footer>
    </section>
  );
}

export function elapsedLabel(startedAt: number | null): string {
  if (!startedAt) return '00:00';
  return duration(Date.now() - startedAt);
}
