import { useEffect, type ReactNode } from 'react';
import { Icon } from './Icons.js';

export function Modal({
  title,
  children,
  footer,
  onClose,
  wide,
}: {
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-modal="true" style={wide ? { width: 'min(720px,100%)' } : undefined}>
        <div className="modal-head">
          <h3>{title}</h3>
          <button className="ghost-ic" onClick={onClose} aria-label="Close">
            <Icon name="i-close" />
          </button>
        </div>
        <div className="modal-body">{children}</div>
        {footer ? <div className="modal-foot">{footer}</div> : null}
      </div>
    </div>
  );
}

export function Btn({
  children,
  kind = 'ghost',
  className = '',
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { kind?: 'primary' | 'ghost' | 'danger' | 'link' }) {
  return (
    <button className={`zbtn ${kind} ${className}`.trim()} {...rest}>
      {children}
    </button>
  );
}

export function Toasts({ items }: { items: { id: number; text: string; kind?: string }[] }) {
  return (
    <div className="toasts">
      {items.map((t) => (
        <div key={t.id} className={`toast ${t.kind ?? ''}`}>
          {t.text}
        </div>
      ))}
    </div>
  );
}

export function Empty({ title, hint }: { title: string; hint?: string }) {
  return (
    <li className="empty">
      <b>{title}</b>
      {hint}
    </li>
  );
}
