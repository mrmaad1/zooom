import { useEffect, useRef, useState } from 'react';
import { Icon } from './Icons.js';
import { Btn, Modal } from './ui.js';
import { formatMeetingId, newMeetingId } from '../lib/format.js';
import type { LocalMedia, MediaState } from '../lib/media.js';
import type { ClientConfig } from '../../shared/protocol.js';

export function ScheduleModal({
  onClose,
  onSave,
}: {
  onClose: () => void;
  onSave: (meeting: { room: string; title: string; when: string; dur: number }) => void;
}) {
  const start = new Date(Date.now() + 30 * 60_000);
  const local = new Date(start.getTime() - start.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
  const [title, setTitle] = useState('Zooom meeting');
  const [when, setWhen] = useState(local);
  const [dur, setDur] = useState(60);
  const [room] = useState(() => newMeetingId());

  return (
    <Modal
      title="Schedule a meeting"
      onClose={onClose}
      footer={
        <>
          <Btn onClick={onClose}>Cancel</Btn>
          <Btn
            kind="primary"
            onClick={() =>
              onSave({ room, title: title.trim() || 'Zooom meeting', when: new Date(when).toISOString(), dur })
            }
          >
            Save
          </Btn>
        </>
      }
    >
      <label className="zfield">
        <span>Topic</span>
        <input value={title} maxLength={80} onChange={(e) => setTitle(e.target.value)} />
      </label>
      <label className="zfield">
        <span>When</span>
        <input type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} />
      </label>
      <label className="zfield">
        <span>Duration (minutes — no cap)</span>
        <input type="number" min={5} step={5} value={dur} onChange={(e) => setDur(Number(e.target.value))} />
      </label>
      <label className="zfield">
        <span>Meeting ID</span>
        <input value={formatMeetingId(room)} readOnly className="mono" />
      </label>
      <p className="hint">Invite links carry the meeting key in the URL fragment, so only invitees can decrypt.</p>
    </Modal>
  );
}

export function SettingsModal({
  media,
  mediaState,
  config,
  privacyMode,
  onPrivacyMode,
  onClose,
}: {
  media: LocalMedia;
  mediaState: MediaState;
  config: ClientConfig | null;
  privacyMode: boolean;
  onPrivacyMode: (value: boolean) => void;
  onClose: () => void;
}) {
  const [mics, setMics] = useState<MediaDeviceInfo[]>([]);
  const [cams, setCams] = useState<MediaDeviceInfo[]>([]);
  const [speakers, setSpeakers] = useState<MediaDeviceInfo[]>([]);
  const [level, setLevel] = useState(0);
  const meterRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        if (cancelled) return;
        setMics(devices.filter((d) => d.kind === 'audioinput'));
        setCams(devices.filter((d) => d.kind === 'videoinput'));
        setSpeakers(devices.filter((d) => d.kind === 'audiooutput'));
      } catch {
        /* ignore */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!media.stream.getAudioTracks().length) return;
    let raf = 0;
    let ctx: AudioContext | null = null;
    try {
      ctx = new AudioContext();
      const source = ctx.createMediaStreamSource(media.stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      source.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      const loop = () => {
        analyser.getByteFrequencyData(data);
        let sum = 0;
        for (const value of data) sum += value;
        setLevel(Math.min(100, (sum / data.length / 255) * 320));
        raf = requestAnimationFrame(loop);
      };
      loop();
    } catch {
      /* ignore */
    }
    return () => {
      cancelAnimationFrame(raf);
      void ctx?.close();
    };
  }, [media]);

  const currentMic = media.mic?.getSettings().deviceId ?? '';
  const currentCam = media.cam?.getSettings().deviceId ?? '';

  return (
    <Modal
      title="Audio & video settings"
      onClose={onClose}
      footer={<Btn kind="primary" onClick={onClose}>Done</Btn>}
    >
      <label className="zfield">
        <span>Microphone</span>
        <select value={currentMic} onChange={(e) => void media.switchDevice('audio', e.target.value)}>
          {mics.length === 0 ? <option value="">No microphone found</option> : null}
          {mics.map((device, index) => (
            <option key={device.deviceId} value={device.deviceId}>
              {device.label || `Microphone ${index + 1}`}
            </option>
          ))}
        </select>
      </label>
      <div>
        <div className="meter" ref={meterRef}>
          <i style={{ width: `${level}%` }} />
        </div>
        <p className="hint" style={{ marginTop: 6 }}>
          {mediaState.micOn ? 'Speak now — the bar shows your input level.' : 'Microphone is muted.'}
        </p>
      </div>

      <label className="zfield">
        <span>Camera</span>
        <select value={currentCam} onChange={(e) => void media.switchDevice('video', e.target.value)}>
          {cams.length === 0 ? <option value="">No camera found</option> : null}
          {cams.map((device, index) => (
            <option key={device.deviceId} value={device.deviceId}>
              {device.label || `Camera ${index + 1}`}
            </option>
          ))}
        </select>
      </label>

      <label className="zfield">
        <span>Speaker</span>
        <select defaultValue="">
          <option value="">System default</option>
          {speakers.map((device, index) => (
            <option key={device.deviceId} value={device.deviceId}>
              {device.label || `Speaker ${index + 1}`}
            </option>
          ))}
        </select>
      </label>

      <label className="switch-row">
        <input type="checkbox" checked={privacyMode} onChange={(e) => onPrivacyMode(e.target.checked)} />
        <span className="switch-ui" />
        <span className="switch-label">Privacy mode — never contact third-party STUN servers</span>
      </label>
      <p className="hint">
        {config?.privacy.publicStun
          ? 'Public STUN helps peers connect across NATs but reveals your IP to that STUN provider. Turn this on if you run your own TURN server.'
          : 'The server is already configured without public STUN.'}
      </p>
    </Modal>
  );
}

export function ProfileModal({
  name,
  onSave,
  onClose,
}: {
  name: string;
  onSave: (name: string) => void;
  onClose: () => void;
}) {
  const [value, setValue] = useState(name);
  return (
    <Modal
      title="Profile"
      onClose={onClose}
      footer={
        <>
          <Btn onClick={onClose}>Cancel</Btn>
          <Btn kind="primary" onClick={() => onSave(value.trim())}>
            Save
          </Btn>
        </>
      }
    >
      <label className="zfield">
        <span>Your name</span>
        <input value={value} maxLength={42} onChange={(e) => setValue(e.target.value)} autoFocus />
      </label>
      <p className="hint">Shown on your home screen and in meetings. Stored only in this browser.</p>
    </Modal>
  );
}

export function RenameModal({
  name,
  onSave,
  onClose,
}: {
  name: string;
  onSave: (name: string) => void;
  onClose: () => void;
}) {
  const [value, setValue] = useState(name);
  return (
    <Modal
      title="Your name"
      onClose={onClose}
      footer={
        <>
          <Btn onClick={onClose}>Cancel</Btn>
          <Btn kind="primary" onClick={() => onSave(value.trim() || 'Guest')}>
            Save
          </Btn>
        </>
      }
    >
      <label className="zfield">
        <span>Display name</span>
        <input value={value} maxLength={42} onChange={(e) => setValue(e.target.value)} autoFocus />
      </label>
    </Modal>
  );
}

export function ParticipantModal({
  name,
  onAskMute,
  onRemove,
  onClose,
}: {
  name: string;
  onAskMute: () => void;
  onRemove: () => void;
  onClose: () => void;
}) {
  return (
    <Modal
      title="Participant"
      onClose={onClose}
      footer={
        <>
          <Btn onClick={onClose}>Close</Btn>
          <Btn onClick={onAskMute}>
            <Icon name="i-mic-off" size="sm" /> Ask to mute
          </Btn>
          <Btn kind="danger" onClick={onRemove}>
            Remove
          </Btn>
        </>
      }
    >
      <p className="hint">
        Manage <b>{name}</b>. Removing a participant disconnects them immediately.
      </p>
    </Modal>
  );
}

export function InfoModal({
  room,
  invite,
  hostName,
  count,
  onCopy,
  onClose,
}: {
  room: string;
  invite: string;
  hostName: string;
  count: number;
  onCopy: () => void;
  onClose: () => void;
}) {
  return (
    <Modal
      title="Meeting info"
      onClose={onClose}
      footer={
        <>
          <Btn onClick={onClose}>Done</Btn>
          <Btn kind="primary" onClick={onCopy}>
            <Icon name="i-link" size="sm" /> Copy invite link
          </Btn>
        </>
      }
    >
      <label className="zfield">
        <span>Meeting ID</span>
        <input readOnly value={formatMeetingId(room)} className="mono" />
      </label>
      <label className="zfield">
        <span>Invite link (contains the E2EE key)</span>
        <input readOnly value={invite} className="mono" onFocus={(e) => e.currentTarget.select()} />
      </label>
      <p className="hint">
        Host: {hostName || 'You'} · {count} participant{count === 1 ? '' : 's'} · media peer-to-peer, chat
        encrypted in the browser.
      </p>
    </Modal>
  );
}

export function UnlockModal({
  onSubmit,
  onLeave,
}: {
  onSubmit: (value: string) => void;
  onLeave: () => void;
}) {
  const [value, setValue] = useState('');
  return (
    <Modal
      title="This meeting is encrypted"
      onClose={onLeave}
      footer={
        <>
          <Btn onClick={onLeave}>Leave</Btn>
          <Btn kind="primary" onClick={() => onSubmit(value)}>
            Unlock
          </Btn>
        </>
      }
    >
      <p className="hint">
        Media and chat in this room are end-to-end encrypted. Paste the invite link you received to unlock it — the
        key stays in your browser and is never sent to the server.
      </p>
      <label className="zfield">
        <span>Invite link or meeting key</span>
        <input value={value} onChange={(e) => setValue(e.target.value)} placeholder="https://…/ ?room=…#k=…" autoFocus />
      </label>
    </Modal>
  );
}
