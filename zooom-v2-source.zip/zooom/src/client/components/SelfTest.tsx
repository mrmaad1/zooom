import { useEffect, useState } from 'react';
import { Icon } from './Icons.js';
import { Btn, Modal } from './ui.js';
import { runSelfTest, type Check } from '../lib/selftest.js';

const ICON: Record<string, { name: string; color: string }> = {
  pass: { name: 'i-check', color: '#4ade80' },
  warn: { name: 'i-info', color: '#fbbf24' },
  fail: { name: 'i-close', color: '#f87171' },
  running: { name: 'i-clock', color: '#93a4bb' },
};

export function SelfTestModal({ onClose }: { onClose: () => void }) {
  const [checks, setChecks] = useState<Check[]>([]);
  const [running, setRunning] = useState(false);

  const run = async () => {
    setRunning(true);
    await runSelfTest(setChecks);
    setRunning(false);
  };

  useEffect(() => {
    void run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const passed = checks.filter((c) => c.status === 'pass').length;
  const failed = checks.filter((c) => c.status === 'fail').length;
  const warned = checks.filter((c) => c.status === 'warn').length;
  const done = checks.length > 0 && !checks.some((c) => c.status === 'running');

  return (
    <Modal
      title="Test my setup"
      onClose={onClose}
      wide
      footer={
        <>
          <Btn onClick={() => void run()} disabled={running}>
            {running ? 'Testing…' : 'Run again'}
          </Btn>
          <Btn kind="primary" onClick={onClose}>
            Done
          </Btn>
        </>
      }
    >
      <p className="hint">
        Checks run locally in this browser. The only network contact is a throwaway WebSocket handshake with this
        server — no media, no keys, nothing stored.
      </p>
      <ul className="selftest-list">
        {checks.map((check) => {
          const icon = ICON[check.status] ?? ICON.running;
          return (
            <li key={check.id} className={`selftest-row is-${check.status}`}>
              <span className="selftest-ic" style={{ color: icon.color }}>
                <Icon name={icon.name} size="sm" />
              </span>
              <span className="selftest-body">
                <b>{check.label}</b>
                <small>{check.detail ?? (check.status === 'running' ? 'checking…' : '')}</small>
              </span>
            </li>
          );
        })}
      </ul>
      {done ? (
        <div className={`selftest-summary ${failed ? 'bad' : warned ? 'warn' : 'good'}`}>
          <b>
            {failed
              ? `${failed} blocking issue${failed === 1 ? '' : 's'}`
              : warned
                ? `${passed} passed · ${warned} warning${warned === 1 ? '' : 's'}`
                : 'Everything looks good'}
          </b>
          <span>
            {failed
              ? 'Fix the red items first — meetings will not work until they are green.'
              : 'Open another browser tab with the same invite link to test a real two-person call.'}
          </span>
        </div>
      ) : null}
    </Modal>
  );
}
