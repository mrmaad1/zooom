import type { ReactNode } from 'react';
import { Icon } from './Icons.js';

export type Tab = 'home' | 'meetings' | 'recordings' | 'more';

export function TopBar({
  name,
  onSearch,
  search,
  onBell,
  onProfile,
  onPlus,
  onRoom,
  e2ee,
  privacyLine,
}: {
  name: string;
  search: string;
  onSearch: (value: string) => void;
  onBell: () => void;
  onProfile: () => void;
  onPlus: () => void;
  onRoom: () => void;
  e2ee: 'on' | 'off' | 'unsupported';
  privacyLine?: string;
}) {
  return (
    <header className="wintop">
      <div className="wbrand">
        <span className="wlogo">
          <svg viewBox="0 0 40 40" aria-hidden="true">
            <defs>
              <linearGradient id="lg" x1="0" y1="0" x2="40" y2="40">
                <stop stopColor="#2D8CFF" />
                <stop offset="1" stopColor="#0B5CFF" />
              </linearGradient>
            </defs>
            <rect width="40" height="40" rx="9" fill="url(#lg)" />
            <path d="M11 16a3 3 0 0 1 3-3h6a3 3 0 0 1 3 3v9a3 3 0 0 1-3 3h-6a3 3 0 0 1-3-3v-9Z" fill="#fff" />
            <path d="M24.6 19.6l3.9-2.4c.7-.4 1.5.1 1.5.9v7.8c0 .8-.8 1.3-1.5.9l-3.9-2.4v-4.8Z" fill="#fff" />
          </svg>
        </span>
        <span className="wbrand-text">
          <b>zooom</b>
          <i>Workplace</i>
        </span>
      </div>

      <div className="wnav-arrows">
        <button className="ghost-ic" title="Back" aria-label="Back">
          <Icon name="i-chev-left" size="sm" />
        </button>
        <button className="ghost-ic" title="Forward" aria-label="Forward">
          <Icon name="i-chev-right" size="sm" />
        </button>
      </div>

      <div className="wsearch">
        <Icon name="i-search" size="sm" />
        <input
          value={search}
          onChange={(e) => onSearch(e.target.value)}
          placeholder="Search (Ctrl+E)"
          aria-label="Search meetings"
        />
        <kbd>Ctrl+E</kbd>
      </div>

      <div className="wtop-right">
        {e2ee !== 'off' ? (
          <span className={e2ee === 'on' ? 'e2ee-chip' : 'e2ee-chip warn'} title={privacyLine ?? 'End-to-end encrypted'}>
            <Icon name="i-lock" size="xs" />
            {e2ee === 'on' ? 'E2EE ready' : 'E2EE n/a'}
          </span>
        ) : null}
        <button className="wplus" title="Create or join" onClick={onPlus}>
          <Icon name="i-plus" size="sm" />
        </button>
        <button className="wroom" title="Your personal room" onClick={onRoom}>
          <Icon name="g-room" size="sm" /> Room
        </button>
        <button className="ghost-ic" title="Notifications" onClick={onBell}>
          <Icon name="i-bell" />
        </button>
        <button className="wavatar" title={name || 'Your profile'} onClick={onProfile}>
          {(name || 'A').trim().charAt(0).toUpperCase()}
        </button>
        <div className="wctrls">
          <button title="Minimize">
            <svg viewBox="0 0 12 12" className="wc">
              <path d="M2.5 6h7" />
            </svg>
          </button>
          <button title="Full screen" onClick={() => document.documentElement.requestFullscreen?.()}>
            <svg viewBox="0 0 12 12" className="wc">
              <rect x="2.6" y="2.6" width="6.8" height="6.8" rx="1" />
            </svg>
          </button>
          <button title="Close" onClick={() => window.close()}>
            <svg viewBox="0 0 12 12" className="wc">
              <path d="M3 3l6 6M9 3l-6 6" />
            </svg>
          </button>
        </div>
      </div>
    </header>
  );
}

const RAIL: { tab: Tab; icon: string; label: string }[] = [
  { tab: 'home', icon: 'i-home', label: 'Home' },
  { tab: 'meetings', icon: 'i-video2', label: 'Meetings' },
  { tab: 'recordings', icon: 'i-doc', label: 'Recordings' },
  { tab: 'more', icon: 'i-more', label: 'More' },
];

export function Rail({
  tab,
  onTab,
  onSettings,
}: {
  tab: Tab;
  onTab: (tab: Tab) => void;
  onSettings: () => void;
}) {
  return (
    <nav className="rail">
      <div className="rail-top">
        {RAIL.map((item) => (
          <button
            key={item.tab}
            className={`rail-item ${tab === item.tab ? 'is-active' : ''}`}
            onClick={() => onTab(item.tab)}
          >
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </button>
        ))}
      </div>
      <div className="rail-bottom">
        <button className="rail-item small" onClick={onSettings}>
          <Icon name="i-gear" />
          <span>Settings</span>
        </button>
      </div>
    </nav>
  );
}

export function AppFrame({ top, rail, children }: { top: ReactNode; rail: ReactNode; children: ReactNode }) {
  return (
    <section className="screen shell is-active">
      {top}
      <div className="wbody">
        {rail}
        <main className="wcontent">{children}</main>
      </div>
    </section>
  );
}
