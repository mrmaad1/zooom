import { useEffect, useMemo, useRef, useState } from 'react';
import { Icon } from './Icons.js';
import { Empty } from './ui.js';
import { ScheduledRow } from './MeetingRow.js';
import type { ScheduledMeeting } from '../lib/storage.js';

function WeekStrip() {
  const days = useMemo(() => {
    const now = new Date();
    const monday = new Date(now);
    monday.setDate(now.getDate() - ((now.getDay() + 6) % 7));
    return Array.from({ length: 7 }, (_, index) => {
      const day = new Date(monday);
      day.setDate(monday.getDate() + index);
      return { label: ['M', 'T', 'W', 'T', 'F', 'S', 'S'][index], date: day.getDate(), today: day.toDateString() === now.toDateString(), past: day < now && day.toDateString() !== now.toDateString() };
    });
  }, []);

  return (
    <div className="week-strip">
      {days.map((day, index) => (
        <div key={index} className={`week-day ${day.today ? 'is-today' : ''} ${day.past ? 'is-past' : ''}`}>
          <span>{day.label}</span>
          <b>{day.date}</b>
        </div>
      ))}
    </div>
  );
}

export function ClockCard({
  meetings,
  onStart,
  onCopy,
  onSchedule,
  onViewAll,
}: {
  meetings: ScheduledMeeting[];
  onStart: (meeting: ScheduledMeeting) => void;
  onCopy: (meeting: ScheduledMeeting) => void;
  onSchedule: () => void;
  onViewAll: () => void;
}) {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 10_000);
    return () => window.clearInterval(id);
  }, []);

  const upcoming = meetings
    .filter((m) => new Date(m.when).getTime() > Date.now() - 3_600_000)
    .sort((a, b) => new Date(a.when).getTime() - new Date(b.when).getTime())
    .slice(0, 4);

  return (
    <aside className="clock-col">
      <div className="clock-card">
        <div className="clock-top">
          <div className="clock-time">{now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</div>
          <div className="clock-date">
            {now.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
          </div>
          <svg className="clock-art" viewBox="0 0 200 120" aria-hidden="true">
            <g opacity=".9">
              <path d="M150 118V70c0-16 12-24 26-24" stroke="#7ee0c0" strokeWidth="7" fill="none" strokeLinecap="round" />
              <ellipse cx="176" cy="46" rx="19" ry="9" fill="#7ee0c0" transform="rotate(-24 176 46)" />
              <ellipse cx="160" cy="34" rx="15" ry="7.5" fill="#a6efd6" transform="rotate(-52 160 34)" />
              <rect x="18" y="86" width="52" height="34" rx="7" fill="#ffffff" opacity=".16" />
              <rect x="26" y="76" width="36" height="14" rx="5" fill="#ffffff" opacity=".26" />
            </g>
          </svg>
        </div>
        <div className="clock-bottom">
          <WeekStrip />
          <div className="card-head row-between">
            <h3>Upcoming meetings</h3>
            <button className="link-btn" onClick={onViewAll}>
              View all
            </button>
          </div>
          <ul className="meeting-list">
            {upcoming.length === 0 ? (
              <Empty title="Nothing scheduled" hint="Hit “Schedule” to plan a meeting — or just start one now." />
            ) : (
              upcoming.map((meeting) => (
                <ScheduledRow
                  key={meeting.id}
                  meeting={meeting}
                  onStart={() => onStart(meeting)}
                  onCopy={() => onCopy(meeting)}
                />
              ))
            )}
          </ul>
          <button className="zbtn clock-cta" onClick={onSchedule}>
            <Icon name="i-plus" size="sm" /> Schedule a meeting
          </button>
        </div>
      </div>
    </aside>
  );
}

export function Home({
  name,
  meetings,
  e2eeSupported,
  onNew,
  onJoin,
  onSchedule,
  onShare,
  onStartMeeting,
  onCopyMeeting,
  onViewAll,
}: {
  name: string;
  meetings: ScheduledMeeting[];
  e2eeSupported: boolean;
  onNew: (variant: 'video' | 'novideo' | 'share') => void;
  onJoin: () => void;
  onSchedule: () => void;
  onShare: () => void;
  onStartMeeting: (meeting: ScheduledMeeting) => void;
  onCopyMeeting: (meeting: ScheduledMeeting) => void;
  onViewAll: () => void;
}) {
  const [menu, setMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!menu) return;
    const onDown = (event: MouseEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) setMenu(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [menu]);

  return (
    <div className="tab-pane is-active">
      <div className="home-layout">
        <div className="launcher-col">
          <div className="launcher">
            <div className="launch-cell">
              <button className="launch-tile orange" onClick={() => onNew('video')} title="Start a new meeting">
                <svg viewBox="0 0 48 48">
                  <use href="#g-camera" />
                </svg>
              </button>
              <div className="launch-label" ref={menuRef}>
                <button className="launch-text" onClick={() => onNew('video')}>
                  New meeting
                </button>
                <button className="launch-caret" aria-label="New meeting options" onClick={() => setMenu((v) => !v)}>
                  <Icon name="i-chev-down" size="xs" />
                </button>
                {menu ? (
                  <div className="popover menu" style={{ position: 'absolute', top: 'calc(100% + 10px)', left: '50%', transform: 'translateX(-50%)' }}>
                    <button onClick={() => { setMenu(false); onNew('video'); }}>
                      <Icon name="i-video" size="sm" /> Start with video
                    </button>
                    <button onClick={() => { setMenu(false); onNew('novideo'); }}>
                      <Icon name="i-video-off" size="sm" /> Start without video
                    </button>
                    <button onClick={() => { setMenu(false); onNew('share'); }}>
                      <Icon name="i-share" size="sm" /> Start and share screen
                    </button>
                  </div>
                ) : null}
              </div>
            </div>

            <div className="launch-cell">
              <button className="launch-tile blue" onClick={onJoin} title="Join a meeting">
                <svg viewBox="0 0 48 48">
                  <use href="#g-plus" />
                </svg>
              </button>
              <div className="launch-label">
                <button className="launch-text" onClick={onJoin}>
                  Join
                </button>
              </div>
            </div>

            <div className="launch-cell">
              <button className="launch-tile blue" onClick={onSchedule} title="Schedule a meeting">
                <svg viewBox="0 0 48 48">
                  <use href="#g-calendar31" />
                </svg>
              </button>
              <div className="launch-label">
                <button className="launch-text" onClick={onSchedule}>
                  Schedule
                </button>
              </div>
            </div>

            <div className="launch-cell">
              <button className="launch-tile blue" onClick={onShare} title="Share your screen">
                <svg viewBox="0 0 48 48">
                  <use href="#g-share" />
                </svg>
              </button>
              <div className="launch-label">
                <button className="launch-text" onClick={onShare}>
                  Share screen
                </button>
              </div>
            </div>
          </div>

          <div className="home-tip">
            <Icon name="i-lock" size="xs" />
            <span>
              <b>Private by design.</b> Media is {e2eeSupported ? 'end-to-end encrypted' : 'encrypted in transit'} · no
              paywall · no time limits.
            </span>
          </div>
        </div>

        <ClockCard
          meetings={meetings}
          onStart={onStartMeeting}
          onCopy={onCopyMeeting}
          onSchedule={onSchedule}
          onViewAll={onViewAll}
        />
      </div>
      <p className="sr-only">{name}</p>
    </div>
  );
}
