/**
 * Smoke test — no browser needed.
 *
 * Verifies the parts a terminal can verify:
 *   1. app + API health
 *   2. security headers
 *   3. WebSocket signaling: two clients join the same room and see each other
 *   4. chat relay carries ciphertext only (server never sees plaintext)
 *   5. host controls (mute-all) and clean leave
 *
 * Real media/E2EE is browser-side — that is what the in-app "Test my setup"
 * panel and a two-tab call are for.
 *
 * Usage:  npm run smoke            (defaults to http://127.0.0.1:3000)
 *         BASE=https://… npm run smoke
 */
import WebSocket from 'ws';

const BASE = process.env.BASE ?? 'http://127.0.0.1:3000';
const WS_BASE = BASE.replace(/^http/, 'ws');

let failures = 0;
const ok = (label, extra = '') => console.log(`  \x1b[32m✔\x1b[0m ${label}${extra ? ` — ${extra}` : ''}`);
const bad = (label, extra = '') => {
  failures += 1;
  console.log(`  \x1b[31m✘\x1b[0m ${label}${extra ? ` — ${extra}` : ''}`);
};
const section = (title) => console.log(`\n\x1b[1m${title}\x1b[0m`);

const room = String(Math.floor(100_000_000 + Math.random() * 899_999_999));
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function client(name) {
  const socket = new WebSocket(`${WS_BASE}/ws`);
  const inbox = [];
  socket.on('message', (raw) => {
    try {
      inbox.push(JSON.parse(raw.toString()));
    } catch {
      /* ignore */
    }
  });
  const opened = new Promise((resolve, reject) => {
    socket.once('open', resolve);
    socket.once('error', reject);
  });
  return {
    socket,
    inbox,
    opened,
    send: (msg) => socket.send(JSON.stringify(msg)),
    async next(type, timeout = 3000) {
      const started = Date.now();
      while (Date.now() - started < timeout) {
        const found = inbox.find((m) => m.type === type);
        if (found) return found;
        await wait(40);
      }
      return null;
    },
  };
}

async function main() {
  console.log(`\nZooom smoke test → ${BASE}\n${'='.repeat(46)}`);

  /* ---------------- 1. app + api ---------------- */
  section('1. App & API');
  const home = await fetch(BASE);
  home.ok ? ok('GET / returns the app', `${home.status}`) : bad('GET / failed', String(home.status));

  const health = await fetch(`${BASE}/api/health`);
  const healthBody = await health.json();
  healthBody.ok ? ok('GET /api/health', JSON.stringify(healthBody)) : bad('health endpoint', JSON.stringify(healthBody));

  const config = await (await fetch(`${BASE}/api/config`)).json();
  Array.isArray(config.iceServers) ? ok('GET /api/config', `${config.iceServers.length} ICE server(s)`) : bad('config missing iceServers');

  /* ---------------- 2. headers ---------------- */
  section('2. Security headers');
  const csp = home.headers.get('content-security-policy');
  csp ? ok('Content-Security-Policy present') : bad('CSP missing');
  const referrer = home.headers.get('referrer-policy');
  referrer === 'no-referrer' ? ok('Referrer-Policy: no-referrer') : bad('referrer policy', String(referrer));
  home.headers.get('x-frame-options') ? ok('X-Frame-Options') : bad('X-Frame-Options missing');
  const permissions = home.headers.get('permissions-policy') ?? '';
  permissions.includes('camera=')
    ? ok('Permissions-Policy restricts camera/mic')
    : bad('Permissions-Policy missing');

  /* ---------------- 3. signaling ---------------- */
  section('3. Signaling (two participants)');
  const alice = client('Alice');
  const bob = client('Bob');
  await Promise.all([alice.opened, bob.opened]);
  ok('Both WebSocket clients connected');

  alice.send({ type: 'join', room, name: 'Alice', muted: false, videoOn: true, e2ee: true });
  const aliceJoined = await alice.next('joined');
  aliceJoined ? ok('Alice joined', `host=${aliceJoined.selfId === aliceJoined.hostId}`) : bad('Alice could not join');

  bob.send({ type: 'join', room, name: 'Bob', muted: true, videoOn: false, e2ee: true });
  const bobJoined = await bob.next('joined');
  bobJoined ? ok('Bob joined the same room', `${bobJoined.participants.length} participant(s)`) : bad('Bob could not join');

  const peerSeen = await alice.next('peer-joined');
  peerSeen ? ok('Alice was told about Bob', peerSeen.participant.name) : bad('peer-joined missing');
  bobJoined?.encrypted ? ok('Room flagged as encrypted') : bad('room encryption flag');

  /* ---------------- 4. state + chat ---------------- */
  section('4. State + encrypted chat relay');
  bob.send({ type: 'hand', hand: true });
  const hand = await alice.next('peer-hand');
  hand?.hand ? ok('Raise-hand propagates') : bad('raise-hand did not propagate');

  const cipher = { ct: 'ZmFrZS1jaXBoZXJ0ZXh0', iv: 'ZmFrZS1pdg' };
  alice.send({ type: 'chat', ct: cipher.ct, iv: cipher.iv, to: 'everyone' });
  // system join/leave lines also arrive as `chat` — wait for our ciphertext
  let relayed = null;
  const deadline = Date.now() + 3000;
  while (Date.now() < deadline && !relayed) {
    relayed = bob.inbox.find((m) => m.type === 'chat' && m.message?.ct);
    if (!relayed) await wait(40);
  }
  if (!relayed) bad('chat was not relayed');
  else {
    const message = relayed.message;
    message.ct === cipher.ct && message.iv === cipher.iv
      ? ok('Chat relayed as ciphertext only', 'server never saw plaintext')
      : bad('chat payload altered', JSON.stringify(message));
    message.text === undefined ? ok('No plaintext field on the relayed message') : bad('plaintext leaked');
  }

  /* ---------------- 5. host controls ---------------- */
  section('5. Host controls + leave');
  alice.send({ type: 'mute-all' });
  const muteReq = await bob.next('mute-request');
  muteReq ? ok('Host can mute everyone') : bad('mute-all did not reach Bob');

  alice.send({ type: 'leave' });
  const left = await bob.next('peer-left', 2000);
  const promoted = await bob.next('host-changed', 2000);
  left ? ok('Leave is propagated') : bad('peer-left missing');
  promoted ? ok('Host transferred to Bob') : bad('host transfer missing');

  bob.send({ type: 'leave' });
  await wait(300);
  for (const c of [alice, bob]) c.socket.close();

  /* ---------------- summary ---------------- */
  console.log(`\n${'='.repeat(46)}`);
  if (failures === 0) {
    console.log('\x1b[32mAll smoke checks passed.\x1b[0m');
    console.log('Next: open the app in two browser tabs and use "Test my setup" + a real call.\n');
    process.exit(0);
  }
  console.log(`\x1b[31m${failures} check(s) failed.\x1b[0m\n`);
  process.exit(1);
}

main().catch((error) => {
  console.error('\x1b[31mSmoke test crashed:\x1b[0m', error);
  process.exit(1);
});
